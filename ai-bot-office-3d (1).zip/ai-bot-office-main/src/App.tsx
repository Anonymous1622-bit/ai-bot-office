import { useEffect, useState } from 'react';
import { Bot, Gamepad2, LayoutDashboard, Settings, Sparkles, TerminalSquare, CalendarClock, UserPlus } from 'lucide-react';
import type { Game } from '@/lib/types';
import { db } from '@/lib/db';
import { isSupabaseConfigured } from '@/lib/supabase';
import Dashboard from '@/components/Dashboard';
import GameProfiles from '@/components/GameProfiles';
import ContentStudio from '@/components/ContentStudio';
import Scheduler from '@/components/Scheduler';
import InviteBot from '@/components/InviteBot';
import ApiSettings from '@/components/ApiSettings';
import GoRedirect from '@/components/GoRedirect';

type Tab = 'dashboard' | 'games' | 'studio' | 'scheduler' | 'invites' | 'settings';

const NAV: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'games', label: 'Game Profiles', icon: Gamepad2 },
  { id: 'studio', label: 'AI Content Studio', icon: Sparkles },
  { id: 'scheduler', label: 'Scheduler', icon: CalendarClock },
  { id: 'invites', label: 'Auto-Invite Bot', icon: UserPlus },
  { id: 'settings', label: 'API Settings', icon: Settings },
];

export default function App() {
  if (window.location.pathname.startsWith('/go/')) return <GoRedirect />;
  return <MainApp />;
}

function MainApp() {
  const [tab, setTab] = useState<Tab>('dashboard');
  const [games, setGames] = useState<Game[]>([]);
  const [autoPilot, setAutoPilot] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [bannerHidden, setBannerHidden] = useState(false);

  useEffect(() => {
    db.listGames()
      .then(setGames)
      .catch((err) => console.error('Failed to load games', err));
  }, [tab]);

  // Auto-Pilot lives in the database (bot_settings); the pg_cron worker reads it 24/7.
  useEffect(() => {
    db.getAutoPilot().then(setAutoPilot).catch((err) => console.error('Failed to load auto-pilot', err));
  }, []);

  const toggleAutoPilot = async (v: boolean) => {
    setAutoPilot(v);
    try {
      await db.setAutoPilot(v);
      await db.log(v ? 'success' : 'warning', 'system', v ? 'Auto-Pilot Mode ENABLED — the server worker now runs 24/7' : 'Auto-Pilot Mode disabled — server worker paused');
    } catch (err) {
      setAutoPilot(!v);
      console.error('Failed to save auto-pilot', err);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0e14] text-slate-200 antialiased">
      {!isSupabaseConfigured && !bannerHidden && (
        <div className="flex items-center justify-center gap-3 bg-amber-500/15 px-4 py-2 text-center text-xs text-amber-300">
          <span>
            Local mode: data is saved in this browser only. To sync with Supabase, add VITE_SUPABASE_URL and
            VITE_SUPABASE_ANON_KEY in Netlify, then redeploy.
          </span>
          <button type="button" onClick={() => setBannerHidden(true)} className="rounded border border-amber-300/30 px-2 py-0.5 hover:bg-amber-300/10">
            Hide
          </button>
        </div>
      )}
      {/* Header */}
      <header className="sticky top-0 z-20 border-b border-white/[0.06] bg-[#0b0e14]/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="flex items-center justify-center rounded-xl bg-emerald-500/15 p-2 text-emerald-400">
              <Bot className="h-5 w-5" />
            </span>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-white sm:text-base">GameGrid Bot Office</h1>
              <p className="text-[11px] text-slate-500">AI Social Auto-Post &amp; Auto-Invite Command Center</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            className="rounded-lg border border-white/[0.08] p-2 text-slate-300 md:hidden"
            aria-label="Toggle navigation"
          >
            <TerminalSquare className="h-5 w-5" />
          </button>
        </div>
        <nav className="mx-auto hidden max-w-7xl gap-1 px-4 pb-2 sm:px-6 md:flex">
          {NAV.map((n) => {
            const Icon = n.icon;
            return (
              <button
                key={n.id}
                type="button"
                onClick={() => setTab(n.id)}
                className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                  tab === n.id ? 'bg-emerald-500/15 text-emerald-300' : 'text-slate-400 hover:bg-white/[0.05] hover:text-white'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {n.label}
              </button>
            );
          })}
        </nav>
        {menuOpen && (
          <nav className="flex flex-col gap-1 border-t border-white/[0.06] px-4 py-2 md:hidden">
            {NAV.map((n) => {
              const Icon = n.icon;
              return (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => {
                    setTab(n.id);
                    setMenuOpen(false);
                  }}
                  className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors ${
                    tab === n.id ? 'bg-emerald-500/15 text-emerald-300' : 'text-slate-400'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {n.label}
                </button>
              );
            })}
          </nav>
        )}
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {tab === 'dashboard' && <Dashboard autoPilot={autoPilot} games={games} />}
        {tab === 'games' && <GameProfiles />}
        {tab === 'studio' && <ContentStudio onQueued={() => db.log('success', 'scheduler', 'New post added to the queue')} />}
        {tab === 'scheduler' && <Scheduler autoPilot={autoPilot} onAutoPilotChange={toggleAutoPilot} />}
        {tab === 'invites' && <InviteBot />}
        {tab === 'settings' && <ApiSettings />}
      </main>
    </div>
  );
}
