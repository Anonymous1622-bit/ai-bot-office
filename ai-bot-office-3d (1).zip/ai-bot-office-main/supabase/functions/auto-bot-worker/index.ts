// Server-side 24/7 bot worker. Triggered every minute by pg_cron (see migration).
// Secrets (set with `supabase secrets set`): GEMINI_API_KEY, DISCORD_WEBHOOK_URL,
// TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID. SUPABASE_URL / SERVICE_ROLE_KEY are injected.
import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const sb = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
const env = (k: string) => Deno.env.get(k) ?? '';
const HOUR = 3600_000;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

type Level = 'info' | 'success' | 'warning' | 'error';
// sources map to the office bots: system=Cipher, ai-studio=Aria, auto-poster=Blaze, auto-inviter=Nova
async function log(level: Level, source: string, message: string) {
  const { error } = await sb.from('bot_logs').insert({ level, source, message });
  if (error) console.error('log failed', error.message);
}

interface Settings {
  auto_pilot_enabled: boolean; max_posts_per_hour: number; max_invites_per_hour: number;
  min_queue_size: number; winner_min_clicks: number; est_audience: number;
  platform_discord: boolean; platform_telegram: boolean;
}

/* ---------- senders ---------- */
async function sendDiscord(text: string, webhook = env('DISCORD_WEBHOOK_URL')) {
  if (!webhook) throw new Error('DISCORD_WEBHOOK_URL secret not set');
  const res = await fetch(webhook, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: text.slice(0, 1990) }) });
  if (!res.ok) throw new Error(`Discord ${res.status}`);
}
async function sendTelegram(text: string, chatId = env('TELEGRAM_CHAT_ID')) {
  const token = env('TELEGRAM_BOT_TOKEN');
  if (!token || !chatId) throw new Error('TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID secret not set');
  const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, text: text.slice(0, 4000) }),
  });
  if (!res.ok) throw new Error(`Telegram ${res.status}`);
}

/* ---------- Gemini ---------- */
async function gemini(prompt: string): Promise<{ a: { content: string; hashtags: string }; b: { content: string; hashtags: string } }> {
  const key = env('GEMINI_API_KEY');
  if (!key) throw new Error('GEMINI_API_KEY secret not set');
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${key}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.9, maxOutputTokens: 900, responseMimeType: 'application/json' } }),
  });
  if (!res.ok) throw new Error(`Gemini ${res.status}`);
  const data = await res.json();
  const raw = String(data?.candidates?.[0]?.content?.parts?.[0]?.text ?? '').replace(/```json|```/g, '').trim();
  const parsed = JSON.parse(raw);
  for (const k of ['a', 'b']) if (typeof parsed?.[k]?.content !== 'string') throw new Error('Gemini returned an unexpected shape');
  return parsed;
}

/* ---------- worker ---------- */
Deno.serve(async () => {
  const summary: Record<string, unknown> = {};
  try {
    // Step A — Cipher: auto-pilot gate + rate limits
    const { data: s, error: sErr } = await sb.from('bot_settings').select('*').eq('id', 1).single();
    if (sErr || !s) throw new Error(`bot_settings unavailable: ${sErr?.message}`);
    const cfg = s as Settings;
    if (!cfg.auto_pilot_enabled) return Response.json({ skipped: 'auto-pilot off' });

    const since = new Date(Date.now() - HOUR).toISOString();
    const [{ count: postsHr }, { count: invitesHr }] = await Promise.all([
      sb.from('scheduled_posts').select('id', { count: 'exact', head: true }).eq('status', 'published').gte('published_at', since),
      sb.from('invite_queue').select('id', { count: 'exact', head: true }).eq('status', 'sent').gte('sent_at', since),
    ]);
    let postBudget = Math.max(0, cfg.max_posts_per_hour - (postsHr ?? 0));
    let inviteBudget = Math.max(0, cfg.max_invites_per_hour - (invitesHr ?? 0));
    if (new Date().getMinutes() % 15 === 0) await log('info', 'system', `Rate limit safe: posts ${postsHr ?? 0}/${cfg.max_posts_per_hour} hr, invites ${invitesHr ?? 0}/${cfg.max_invites_per_hour} hr.`);
    if (postBudget === 0) await log('warning', 'system', 'Post rate limit reached — holding publishes until next hour.');

    const platforms = [cfg.platform_discord && 'discord', cfg.platform_telegram && 'telegram'].filter(Boolean) as string[];

    // Step B — Aria: refill queue with A/B variants
    const { count: upcoming } = await sb.from('scheduled_posts').select('id', { count: 'exact', head: true }).eq('status', 'queued').gt('scheduled_at', new Date().toISOString());
    if ((upcoming ?? 0) < cfg.min_queue_size && platforms.length) {
      const { data: games } = await sb.from('games').select('*').eq('active', true).limit(20);
      const game = games?.length ? games[Math.floor(Math.random() * games.length)] : null;
      if (game) {
        try {
          await log('info', 'ai-studio', `Drafting Variant A & B hooks for ${game.title}...`);
          const { data: last } = await sb.from('ab_results').select('variant_group, winner').eq('game_id', game.id).order('decided_at', { ascending: false }).limit(1).maybeSingle();
          let winnerHint = '';
          if (last) {
            const { data: w } = await sb.from('scheduled_posts').select('content').eq('variant_group', last.variant_group).eq('variant', last.winner).limit(1).maybeSingle();
            if (w) winnerHint = `\nA previous test was won by this style — keep that angle for both variants but vary the wording:\n"""${w.content.slice(0, 400)}"""`;
          }
          const group = crypto.randomUUID();
          const track = (v: string) => `${env('SUPABASE_URL')}/functions/v1/track-click?c=${group}&v=${v}`;
          const out = await gemini(`You are a copywriter for an indie game studio. Write TWO promo posts for an A/B test.
Game: ${game.title}\nGenre: ${game.genre || 'n/a'}\nDescription: ${game.description || 'n/a'}${winnerHint}
Variant A angle: hype, FOMO, limited-time reward. Variant B angle: competitive challenge, gameplay curiosity.
Under 600 characters each. Do NOT include any URL. Return ONLY JSON: {"a":{"content":"...","hashtags":"#a #b #c"},"b":{"content":"...","hashtags":"#a #b #c"}}`);
          const start = Date.now() + 5 * 60_000;
          const rows = (['a', 'b'] as const).map((v, i) => ({
            game_id: game.id, game_title: game.title, platforms, tone: v === 'a' ? 'fomo' : 'competitive',
            content: `${out[v].content}\n${track(v)}`, hashtags: out[v].hashtags,
            status: 'queued', scheduled_at: new Date(start + i * 30 * 60_000).toISOString(), variant_group: group, variant: v,
          }));
          const { error } = await sb.from('scheduled_posts').insert(rows);
          if (error) throw new Error(error.message);
          summary.generated = rows.length;
          await log('success', 'ai-studio', `Aria queued Variant A & B for ${game.title}`);
        } catch (e) {
          await log('error', 'ai-studio', `Auto-generate failed: ${(e as Error).message}`);
        }
      }
    }

    // Step C — Blaze: publish due posts
    const { data: due } = await sb.from('scheduled_posts').select('*').eq('status', 'queued').lte('scheduled_at', new Date().toISOString()).order('scheduled_at').limit(10);
    let published = 0;
    for (const post of due ?? []) {
      if (postBudget <= 0) break;
      const text = `${post.content}\n\n${post.hashtags}`.trim();
      const targets = (post.platforms as string[]).filter((p) => (p === 'discord' && cfg.platform_discord) || (p === 'telegram' && cfg.platform_telegram));
      const sent: string[] = [];
      const errors: string[] = [];
      for (const p of targets) {
        try { p === 'discord' ? await sendDiscord(text) : await sendTelegram(text); sent.push(p); }
        catch (e) { errors.push(`${p}: ${(e as Error).message}`); }
      }
      if (sent.length) {
        await sb.from('scheduled_posts').update({ status: 'published', published_at: new Date().toISOString(), impressions: cfg.est_audience, error: errors.join('; ') || null }).eq('id', post.id);
        postBudget--; published++;
        await log('success', 'auto-poster', `Published "${post.game_title}"${post.variant ? ` Variant ${String(post.variant).toUpperCase()}` : ''} to ${sent.join(', ')}`);
      } else {
        await sb.from('scheduled_posts').update({ status: 'failed', error: errors.join('; ') || 'No enabled platform for this post' }).eq('id', post.id);
        await log('error', 'auto-poster', `Failed to publish "${post.game_title}": ${errors.join('; ') || 'no enabled platform'}`);
      }
    }
    summary.published = published;

    // Step D — Nova: process invites within the hourly limit
    const { data: invites } = await sb.from('invite_queue').select('*').eq('status', 'pending').order('created_at').limit(Math.min(inviteBudget, 5));
    let invited = 0;
    for (const inv of invites ?? []) {
      if (inviteBudget <= 0) break;
      try {
        if (inv.platform === 'telegram') await sendTelegram(inv.message, /^-?\d+$/.test(inv.target_user) ? inv.target_user : undefined);
        else await sendDiscord(inv.message);
        await sb.from('invite_queue').update({ status: 'sent', sent_at: new Date().toISOString(), error: null }).eq('id', inv.id);
        inviteBudget--; invited++;
        await log('success', 'auto-inviter', `[${inv.platform}] Sent invite to ${inv.target_user}`);
      } catch (e) {
        await sb.from('invite_queue').update({ status: 'failed', error: (e as Error).message }).eq('id', inv.id);
        await log('error', 'auto-inviter', `[${inv.platform}] Invite to ${inv.target_user} failed: ${(e as Error).message}`);
      }
      await sleep(1500 + Math.random() * 2500); // randomized anti-ban delay (kept short for the function time limit)
    }
    summary.invited = invited;

    // Step E — Cipher: A/B winner check
    const { data: decided } = await sb.from('ab_results').select('variant_group');
    const done = new Set((decided ?? []).map((r) => r.variant_group));
    const { data: ab } = await sb.from('scheduled_posts').select('game_id, variant_group, variant, clicks, impressions').eq('status', 'published').not('variant_group', 'is', null);
    const groups = new Map<string, Record<string, { clicks: number; imp: number }> & { game?: string }>();
    for (const r of ab ?? []) {
      const g = groups.get(r.variant_group) ?? {};
      g[r.variant] = { clicks: (g[r.variant]?.clicks ?? 0) + r.clicks, imp: (g[r.variant]?.imp ?? 0) + r.impressions };
      g.game = r.game_id;
      groups.set(r.variant_group, g);
    }
    for (const [group, g] of groups) {
      if (done.has(group) || !g.a || !g.b) continue;
      if (g.a.clicks + g.b.clicks < cfg.winner_min_clicks) continue;
      const ctrA = (g.a.clicks / Math.max(g.a.imp, 1)) * 100, ctrB = (g.b.clicks / Math.max(g.b.imp, 1)) * 100;
      if (ctrA === ctrB) continue;
      const winner = ctrA > ctrB ? 'a' : 'b';
      await sb.from('ab_results').insert({ variant_group: group, game_id: g.game, winner, ctr_a: ctrA, ctr_b: ctrB });
      await log('success', 'system', `Variant ${winner.toUpperCase()} winning at ${Math.max(ctrA, ctrB).toFixed(1)}% CTR! Switching future posts to Variant ${winner.toUpperCase()}...`);
      await log('info', 'auto-poster', `Blaze: future auto-generated posts will use the Variant ${winner.toUpperCase()} style.`);
    }

    return Response.json({ ok: true, ...summary });
  } catch (e) {
    await log('error', 'system', `Worker run failed: ${(e as Error).message}`);
    return Response.json({ ok: false, error: (e as Error).message }, { status: 500 });
  }
});
