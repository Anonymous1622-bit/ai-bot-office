import { useEffect, useState } from 'react';
import { CalendarClock, CheckCircle2, MousePointerClick, Send, TrendingUp, Zap } from 'lucide-react';
import type { BotLog, Game, Post } from '@/lib/types';
import { db, subscribeLogs } from '@/lib/db';
import { Card } from './ui';
import ActivityConsole from './ActivityConsole';
import OfficeHub from './OfficeHub';
import AbExperiments from './AbExperiments';

interface Stat {
  label: string;
  value: string;
  sub: string;
  icon: typeof Send;
  accent: string;
}

function formatWhen(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  const isToday = d.toDateString() === today.toDateString();
  return isToday
    ? `Today ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
    : d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function Dashboard({ autoPilot, games }: { autoPilot: boolean; games: Game[] }) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [logs, setLogs] = useState<BotLog[]>([]);
  const [inviteCount, setInviteCount] = useState(0);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const [postData, logData] = await Promise.all([db.listPosts(), db.listLogs(60)]);
        if (!mounted) return;
        setPosts(postData);
        setLogs(logData);
        setInviteCount(
          logData.filter((l) => l.source === 'auto-inviter' && l.message.startsWith('Sent invite')).length
        );
      } catch (err) {
        console.error('Dashboard load failed', err);
      }
    };
    void load();
    const t = window.setInterval(() => void load(), 5000);
    // Realtime: the server worker writes bot_logs; the Virtual Office reacts instantly.
    const unsubscribe = subscribeLogs(() => void load());
    return () => {
      mounted = false;
      window.clearInterval(t);
      unsubscribe();
    };
  }, []);

  const scheduled = posts.filter((p) => p.status === 'scheduled').length;
  const published = posts.filter((p) => p.status === 'published').length;
  const clickRate = published > 0 ? ((published * 7.4) % 100).toFixed(1) : '0.0';
  const activeGames = games.filter((g) => g.active).length;

  const stats: Stat[] = [
    { label: 'Posts Scheduled', value: String(scheduled), sub: 'in the queue', icon: CalendarClock, accent: 'text-sky-400 bg-sky-500/10' },
    { label: 'Posts Published', value: String(published), sub: 'all time', icon: CheckCircle2, accent: 'text-emerald-400 bg-emerald-500/10' },
    { label: 'Auto-Invites Sent', value: String(inviteCount), sub: 'last 200 log events', icon: Send, accent: 'text-amber-400 bg-amber-500/10' },
    { label: 'Click / Engagement Rate', value: `${clickRate}%`, sub: 'simulated', icon: MousePointerClick, accent: 'text-fuchsia-400 bg-fuchsia-500/10' },
  ];

  const upcoming = posts
    .filter((p) => p.status === 'scheduled')
    .sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <OfficeHub logs={logs} autoPilot={autoPilot} />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="p-5 transition-transform duration-200 hover:-translate-y-0.5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-medium text-slate-400">{s.label}</p>
                  <p className="mt-2 text-3xl font-bold tracking-tight text-white">{s.value}</p>
                  <p className="mt-1 text-xs text-slate-500">{s.sub}</p>
                </div>
                <span className={`rounded-lg p-2.5 ${s.accent}`}>
                  <Icon className="h-5 w-5" />
                </span>
              </div>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Upcoming Scheduled Posts</h3>
            <TrendingUp className="h-4 w-4 text-slate-500" />
          </div>
          {upcoming.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500">
              Nothing scheduled yet. Generate a post and queue it from the AI Studio or Scheduler.
            </p>
          ) : (
            <ul className="mt-3 divide-y divide-white/[0.05]">
              {upcoming.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm text-white">{p.content.split('\n')[0]}</p>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {p.game_title} · {p.platforms.join(', ')}
                    </p>
                  </div>
                  <span className="shrink-0 text-xs font-medium text-slate-400">{formatWhen(p.scheduled_at)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Bot Engine</h3>
            <Zap className={`h-4 w-4 ${autoPilot ? 'text-emerald-400' : 'text-slate-500'}`} />
          </div>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex items-center justify-between rounded-lg bg-white/[0.03] px-3 py-2.5">
              <span className="text-slate-400">Auto-Pilot Mode</span>
              <span className={autoPilot ? 'font-medium text-emerald-400' : 'text-slate-500'}>
                {autoPilot ? 'Running' : 'Off'}
              </span>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-white/[0.03] px-3 py-2.5">
              <span className="text-slate-400">Active Games</span>
              <span className="text-white">{activeGames}</span>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-white/[0.03] px-3 py-2.5">
              <span className="text-slate-400">Worker Heartbeat</span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                Live
              </span>
            </div>
          </div>
        </Card>
      </div>

      <AbExperiments />

      <ActivityConsole />
    </div>
  );
}
