import { useEffect, useState } from 'react';
import { Copy, FlaskConical, Send, Sparkles, Wand2 } from 'lucide-react';
import type { Game, Platform, Tone } from '@/lib/types';
import { PLATFORMS, TONES } from '@/lib/types';
import { db } from '@/lib/db';
import { generatePost } from '@/lib/generator';
import { createExperiment, newCampaignId, newVariant, trackingUrl, type VariantKey } from '@/lib/ab';
import { Button, Card, EmptyState, Select, TextArea, Toggle } from './ui';
import PhonePreview from './PhonePreview';

type Copy2 = { content: string; hashtags: string };

async function generateWithApi(
  game: Game,
  platform: Platform,
  tone: Tone
): Promise<{ content: string; hashtags: string } | 'no_key'> {
  const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-post`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    },
    body: JSON.stringify({
      game: {
        title: game.title,
        genre: game.genre,
        description: game.description,
        promo_link: game.promo_link,
      },
      platform,
      tone,
    }),
  });
  if (res.status === 503) return 'no_key';
  if (!res.ok) throw new Error(`AI request failed (${res.status})`);
  const data = await res.json();
  if (typeof data.content !== 'string' || typeof data.hashtags !== 'string') {
    throw new Error('AI response was not in the expected format');
  }
  return { content: data.content, hashtags: data.hashtags };
}

function toLocalInput(d: Date) {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export default function ContentStudio({ onQueued }: { onQueued: () => void }) {
  const [games, setGames] = useState<Game[]>([]);
  const [gameId, setGameId] = useState('');
  const [tone, setTone] = useState<Tone>('hype');
  const [platforms, setPlatforms] = useState<Platform[]>(['twitter']);
  const [content, setContent] = useState('');
  const [hashtags, setHashtags] = useState('');
  const [when, setWhen] = useState(() => toLocalInput(new Date(Date.now() + 3600_000)));
  const [generating, setGenerating] = useState(false);
  const [msg, setMsg] = useState('');
  const [abOn, setAbOn] = useState(false);
  const [ab, setAb] = useState<Record<VariantKey, Copy2> | null>(null);
  const [previewKey, setPreviewKey] = useState<VariantKey>('a');
  const [campaignId, setCampaignId] = useState('');

  useEffect(() => {
    db.listGames()
      .then((g) => {
        setGames(g);
        if (g.length > 0) setGameId((prev) => prev || g[0].id);
      })
      .catch((err) => setMsg(err instanceof Error ? err.message : 'Failed to load games'));
  }, []);

  const game = games.find((g) => g.id === gameId);

  const togglePlatform = (p: Platform) => {
    setPlatforms((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]));
  };

  const showAb = abOn && ab !== null;
  const curContent = showAb ? ab![previewKey].content : content;
  const curTags = showAb ? ab![previewKey].hashtags : hashtags;
  const hasCopy = showAb || content !== '';
  const editVariant = (k: VariantKey, patch: Partial<Copy2>) =>
    setAb((prev) => (prev ? { ...prev, [k]: { ...prev[k], ...patch } } : prev));
  const previewPlatform = platforms[0] === 'discord' ? 'discord' : platforms[0] === 'telegram' ? 'telegram' : 'facebook';
  const previewLink = showAb && campaignId ? trackingUrl(campaignId, previewKey) : game?.promo_link ?? '';

  const generateAb = async () => {
    if (!game) return;
    const id = newCampaignId();
    setCampaignId(id);
    setGenerating(true);
    setMsg('');
    await db.log('info', 'ai-studio', `Drafting Variant A & B hooks for ${game.title}...`);
    await new Promise((r) => setTimeout(r, 700));
    const mk = (k: VariantKey, t: Tone): Copy2 => {
      const g = generatePost(game, platforms[0], t);
      const url = trackingUrl(id, k);
      const text = game.promo_link && g.content.includes(game.promo_link) ? g.content.replace(game.promo_link, url) : `${g.content}\n${url}`;
      return { content: text, hashtags: g.hashtags };
    };
    setAb({ a: mk('a', 'fomo'), b: mk('b', 'competitive') });
    setPreviewKey('a');
    await db.log('success', 'ai-studio', `Aria drafted Variant A (Hype/FOMO) and Variant B (Competitive/Curiosity) for ${game.title}`);
    setGenerating(false);
  };

  const generate = async () => {
    if (!game) {
      setMsg('Add a game profile first.');
      return;
    }
    if (platforms.length === 0) {
      setMsg('Pick at least one platform.');
      return;
    }
    if (abOn) {
      await generateAb();
      return;
    }
    setGenerating(true);
    setMsg('');
    let result: { content: string; hashtags: string };
    try {
      const apiResult = await generateWithApi(game, platforms[0], tone);
      if (apiResult === 'no_key') {
        await new Promise((r) => setTimeout(r, 600));
        result = generatePost(game, platforms[0], tone);
        await db.log(
          'warning',
          'ai-studio',
          'No Gemini/OpenAI key configured yet — used the built-in template generator instead'
        );
        setMsg('Using built-in templates. Add your Gemini or OpenAI key (see API Settings) for real AI posts.');
      } else {
        result = apiResult;
        await db.log('success', 'ai-studio', `AI (Gemini) generated a ${tone} post for ${game.title}`);
      }
    } catch (err) {
      result = generatePost(game, platforms[0], tone);
      await db.log(
        'error',
        'ai-studio',
        `AI request failed — fell back to templates (${err instanceof Error ? err.message : 'unknown error'})`
      );
      setMsg('The AI service could not be reached, so a template post was used instead.');
    }
    setContent(result.content);
    setHashtags(result.hashtags);
    setGenerating(false);
  };

  const queue = async () => {
    if (!game || !hasCopy) return;
    const scheduledAt = new Date(when);
    if (Number.isNaN(scheduledAt.getTime())) {
      setMsg('Pick a valid date and time.');
      return;
    }
    const base = { game_id: game.id, game_title: game.title, platforms, tone, status: 'scheduled' as const };
    try {
      if (showAb) {
        for (const k of ['a', 'b'] as VariantKey[]) {
          const at = new Date(scheduledAt.getTime() + (k === 'b' ? 30 * 60_000 : 0));
          await db.savePost({ ...base, content: ab![k].content, hashtags: ab![k].hashtags, scheduled_at: at.toISOString() });
        }
        createExperiment(
          campaignId || newCampaignId(), game.title, game.promo_link,
          newVariant('a', 'Hype & FOMO', ab!.a.content, ab!.a.hashtags),
          newVariant('b', 'Competitive / Curiosity', ab!.b.content, ab!.b.hashtags)
        );
        await db.log('success', 'auto-poster', `Aria handed A/B test for ${game.title} to Blaze — publishing Variant A & B (tracking /go/${campaignId}/a|b)`);
        setAb(null);
      } else {
        await db.savePost({ ...base, content, hashtags, scheduled_at: scheduledAt.toISOString() });
        await db.log('success', 'auto-poster', `Aria handed "${game.title}" post to Blaze — queued for ${scheduledAt.toLocaleString()}`);
        setContent('');
        setHashtags('');
      }
      setMsg('Approved! Blaze has the post in the queue.');
      onQueued();
    } catch (err) {
      setMsg(err instanceof Error ? err.message : 'Failed to queue post');
    }
  };

  if (games.length === 0) {
    return (
      <Card>
        <EmptyState
          icon={<Wand2 className="h-10 w-10" />}
          title="No game profiles yet"
          subtitle="Add a game in Game Profiles first — the AI needs something to promote."
        />
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-5">
      <Card className="p-5 lg:col-span-2">
        <h3 className="text-sm font-semibold text-white">AI Content Studio</h3>
        <p className="mt-0.5 text-xs text-slate-400">Generate platform-tuned captions, hooks and hashtags.</p>

        <div className="mt-4 space-y-4">
          <Select
            label="Game"
            value={gameId}
            onChange={setGameId}
            options={games.map((g) => ({ value: g.id, label: g.title }))}
          />

          <div>
            <span className="mb-1.5 block text-xs font-medium text-slate-400">Tone</span>
            <div className="grid grid-cols-2 gap-2">
              {TONES.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTone(t.id)}
                  className={`rounded-lg border px-3 py-2 text-left text-xs transition-colors ${
                    tone === t.id
                      ? 'border-emerald-500/60 bg-emerald-500/10 text-emerald-300'
                      : 'border-white/[0.08] bg-white/[0.03] text-slate-400 hover:border-white/[0.2]'
                  }`}
                >
                  <span className="block font-semibold">{t.label}</span>
                  <span className="mt-0.5 block text-[10px] leading-snug opacity-70">{t.hint}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="mb-1.5 block text-xs font-medium text-slate-400">Target Platforms</span>
            <div className="flex flex-wrap gap-2">
              {PLATFORMS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => togglePlatform(p.id)}
                  className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
                    platforms.includes(p.id)
                      ? 'border-emerald-500/60 bg-emerald-500/10 text-emerald-300'
                      : 'border-white/[0.08] bg-white/[0.03] text-slate-400 hover:border-white/[0.2]'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2.5">
            <FlaskConical className="h-4 w-4 text-fuchsia-400" />
            <div className="flex-1"><Toggle checked={abOn} onChange={(v) => { setAbOn(v); setPreviewKey('a'); }} label="Enable A/B Split Test" /></div>
          </div>

          <Button className="w-full" onClick={generate} disabled={generating}>
            {generating ? <Sparkles className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
            {generating ? 'Generating…' : 'Generate Post'}
          </Button>
        </div>
      </Card>

      <Card className="p-5 lg:col-span-3">
        <h3 className="text-sm font-semibold text-white">Preview &amp; Schedule</h3>
        <p className="mt-0.5 text-xs text-slate-400">Edit the copy — the phone updates live — then approve and hand it to Blaze.</p>

        {hasCopy ? (
          <div className="mt-4 grid grid-cols-1 gap-6 xl:grid-cols-[1fr_320px]">
            <div className="space-y-4">
              {showAb ? (
                <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                  {(['a', 'b'] as VariantKey[]).map((k) => (
                    <div key={k} className={`space-y-2 rounded-lg border p-3 ${previewKey === k ? 'border-emerald-500/50 bg-emerald-500/[0.04]' : 'border-white/[0.08]'}`}>
                      <button type="button" onClick={() => setPreviewKey(k)} className="flex w-full items-center justify-between text-xs font-semibold text-white">
                        <span>Variant {k.toUpperCase()} · {k === 'a' ? 'Hype / FOMO' : 'Competitive / Curiosity'}</span>
                        <span className="text-[10px] font-normal text-emerald-400">{previewKey === k ? 'in preview' : 'preview'}</span>
                      </button>
                      <TextArea label="Copy" value={ab![k].content} onChange={(v) => editVariant(k, { content: v })} rows={7} />
                      <TextArea label="Hashtags" value={ab![k].hashtags} onChange={(v) => editVariant(k, { hashtags: v })} rows={1} />
                      <p className="break-all font-mono text-[10px] text-slate-500">/go/{campaignId}/{k}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <>
                  <TextArea label="Post Copy" value={content} onChange={setContent} rows={8} />
                  <TextArea label="Hashtags" value={hashtags} onChange={setHashtags} rows={1} />
                </>
              )}

              <label className="block">
                <span className="mb-1.5 block text-xs font-medium text-slate-400">Schedule For</span>
                <input
                  type="datetime-local"
                  value={when}
                  onChange={(e) => setWhen(e.target.value)}
                  className="w-full rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2 text-sm text-white outline-none [color-scheme:dark] focus:border-emerald-500/50"
                />
              </label>
              <Button variant="secondary" onClick={() => navigator.clipboard?.writeText(`${curContent}\n${curTags}`)}>
                <Copy className="h-4 w-4" /> Copy
              </Button>
            </div>

            <div className="space-y-3">
              <PhonePreview
                key={previewPlatform}
                initialPlatform={previewPlatform}
                title={game?.title ?? ''}
                content={curContent}
                hashtags={curTags}
                link={previewLink}
                banner={game?.banner_image ?? ''}
              />
              <Button className="w-full" onClick={queue}>
                <Send className="h-4 w-4" /> Approve &amp; Hand Off to Blaze
              </Button>
            </div>
          </div>
        ) : (
          <EmptyState
            icon={<Sparkles className="h-10 w-10" />}
            title="Nothing generated yet"
            subtitle="Pick a game, choose a tone, and hit Generate Post."
          />
        )}
        {msg && <p className="mt-3 text-sm text-amber-400">{msg}</p>}
      </Card>
    </div>
  );
}
