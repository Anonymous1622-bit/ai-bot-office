import { useEffect, useRef, useState } from 'react';
import { AGENT_BY_ID as AGENT_DEFS, type AgentId } from './agents';
import type { BotLog } from './types';
import type { AgentStatus } from './agents';

export interface AgentActivity {
  status: AgentStatus;
  bubble: string;
  /** increments each time the agent completes an action, for badge counters */
  actions: number;
  /** timestamp of last activity, drives idle decay */
  lastActive: number;
}

const IDLE_AFTER_MS = 18_000;

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function useAgentActivity(
  logs: BotLog[],
  autoPilot: boolean,
  paused: Record<string, boolean>
): Record<AgentId, AgentActivity> {
  const [activity, setActivity] = useState<Record<AgentId, AgentActivity>>(() => ({
    aria: { status: 'idle', bubble: 'Booting up…', actions: 0, lastActive: 0 },
    blaze: { status: 'idle', bubble: 'Booting up…', actions: 0, lastActive: 0 },
    nova: { status: 'idle', bubble: 'Booting up…', actions: 0, lastActive: 0 },
    cipher: { status: 'idle', bubble: 'Booting up…', actions: 0, lastActive: 0 },
  }));

  const prevLogIds = useRef<Set<string>>(new Set());
  const initialized = useRef(false);

  // Map incoming logs to agent activity
  useEffect(() => {
    if (logs.length === 0) return;
    if (!initialized.current) {
      // first load: mark all existing logs as seen without animating
      logs.forEach((l) => prevLogIds.current.add(l.id));
      initialized.current = true;
      return;
    }

    const fresh = logs.filter((l) => !prevLogIds.current.has(l.id));
    if (fresh.length === 0) return;
    fresh.forEach((l) => prevLogIds.current.add(l.id));

    setActivity((prev) => {
      const next = { ...prev };
      for (const log of fresh) {
        const agent = (['aria', 'blaze', 'nova', 'cipher'] as AgentId[]).find((id) => {
          const def = AGENT_DEFS[id];
          return def.sources.includes(log.source);
        });
        if (!agent) continue;
        if (paused[agent]) continue;

        const isSend = log.level === 'success';
        next[agent] = {
          status: isSend ? 'posting' : 'thinking',
          bubble: log.message,
          actions: next[agent].actions + 1,
          lastActive: Date.now(),
        };
      }
      return next;
    });
  }, [logs, paused]);

  // Idle decay: agents drift back to idle, occasionally mumbling idle lines
  useEffect(() => {
    const t = window.setInterval(() => {
      setActivity((prev) => {
        const next = { ...prev };
        for (const id of ['aria', 'blaze', 'nova', 'cipher'] as AgentId[]) {
          const cur = next[id];
          if (paused[id]) {
            if (cur.status !== 'paused') {
              next[id] = { ...cur, status: 'paused', bubble: 'Paused by operator.' };
            }
            continue;
          }
          if (cur.status === 'paused') {
            next[id] = { ...cur, status: 'idle', bubble: pick(AGENT_DEFS[id].idleLines) };
            continue;
          }
          if (cur.status !== 'idle' && Date.now() - cur.lastActive > IDLE_AFTER_MS) {
            next[id] = { ...cur, status: 'idle', bubble: pick(AGENT_DEFS[id].idleLines) };
          }
        }
        return next;
      });
    }, 3000);
    return () => window.clearInterval(t);
  }, [paused]);

  // Auto-pilot idle chatter: keeps agents visibly alive when nothing is happening
  useEffect(() => {
    if (!autoPilot) return;
    const t = window.setInterval(() => {
      setActivity((prev) => {
        const next = { ...prev };
        for (const id of ['aria', 'blaze', 'nova', 'cipher'] as AgentId[]) {
          if (paused[id]) continue;
          if (next[id].status === 'idle' && Math.random() < 0.35) {
            next[id] = { ...next[id], status: 'thinking', bubble: pick(AGENT_DEFS[id].idleLines), lastActive: Date.now() };
          }
        }
        return next;
      });
    }, 6000);
    return () => window.clearInterval(t);
  }, [autoPilot, paused]);

  return activity;
}

