/**
 * A/B experiment store. Uses localStorage so everything works out of the box
 * (mock fallback); swap the load/save functions for Supabase `link_clicks` /
 * `ab_experiments` tables when you are ready (see supabase/migrations).
 */
export type VariantKey = 'a' | 'b';

export interface Variant {
  key: VariantKey;
  angle: string;
  content: string;
  hashtags: string;
  impressions: number;
  clicks: number;
  conversions: number;
  paused: boolean;
}

export interface Experiment {
  id: string;
  game_title: string;
  promo_link: string;
  created_at: number;
  status: 'active' | 'completed';
  variants: Record<VariantKey, Variant>;
  /** cumulative clicks over time */
  series: { t: number; a: number; b: number }[];
  promoted: VariantKey | null;
}

export interface ClickLog {
  id: string;
  campaign: string;
  variant: VariantKey;
  at: number;
  platform: string;
  device: string;
}

export const MIN_CLICKS = 50;
export const MIN_HOURS = 24;
const KEY = 'ab_experiments_v1';
const CLICKS = 'ab_clicks_v1';
const AUTO = 'ab_autopromote_v1';

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable: keep running in-memory only */
  }
}

const mkVariant = (key: VariantKey, angle: string, imp: number, clk: number, conv: number): Variant => ({
  key, angle, content: '', hashtags: '', impressions: imp, clicks: clk, conversions: conv, paused: false,
});

function seed(): Experiment[] {
  const now = Date.now();
  const series = (a: number, b: number, n: number) =>
    Array.from({ length: n }, (_, i) => ({ t: now - (n - i) * 3600_000, a: Math.round((a * (i + 1)) / n), b: Math.round((b * (i + 1)) / n) }));
  return [
    {
      id: 'demo-live', game_title: 'Sample Game', promo_link: 'https://example.com/play', created_at: now - 6 * 3600_000,
      status: 'active', promoted: null, series: series(21, 24, 8),
      variants: { a: mkVariant('a', 'Hype & FOMO', 640, 21, 6), b: mkVariant('b', 'Competitive / Curiosity', 628, 24, 8) },
    },
    {
      id: 'demo-done', game_title: 'Sample Game', promo_link: 'https://example.com/play', created_at: now - 3 * 86400_000,
      status: 'completed', promoted: 'b', series: series(96, 141, 12),
      variants: { a: mkVariant('a', 'Hype & FOMO', 2100, 96, 25), b: mkVariant('b', 'Competitive / Curiosity', 2080, 141, 41) },
    },
  ];
}

export function loadExperiments(): Experiment[] {
  const stored = read<Experiment[] | null>(KEY, null);
  if (stored && stored.length) return stored;
  const s = seed();
  write(KEY, s);
  return s;
}
export const saveExperiments = (e: Experiment[]) => write(KEY, e);
export const getAutoPromote = () => read<boolean>(AUTO, false);
export const setAutoPromote = (v: boolean) => write(AUTO, v);
export const listClicks = () => read<ClickLog[]>(CLICKS, []);

export const ctr = (v: Variant) => (v.impressions ? (v.clicks / v.impressions) * 100 : 0);

/** Winner = higher CTR once 50 total clicks OR 24h have passed. */
export function winnerOf(e: Experiment): VariantKey | null {
  const total = e.variants.a.clicks + e.variants.b.clicks;
  const aged = Date.now() - e.created_at >= MIN_HOURS * 3600_000;
  if (total < MIN_CLICKS && !aged) return null;
  const a = ctr(e.variants.a), b = ctr(e.variants.b);
  if (a === b) return null;
  return a > b ? 'a' : 'b';
}

export const newCampaignId = () => Math.random().toString(36).slice(2, 8);
export const trackingUrl = (id: string, v: VariantKey) => `${window.location.origin}/go/${id}/${v}`;
export const destination = (link: string, v: VariantKey) =>
  `${link}${link.includes('?') ? '&' : '?'}ref=bot_var${v.toUpperCase()}`;

export function createExperiment(id: string, game_title: string, promo_link: string, a: Variant, b: Variant) {
  const all = loadExperiments().filter((e) => e.id !== id);
  const exp: Experiment = {
    id, game_title, promo_link, created_at: Date.now(), status: 'active', promoted: null,
    series: [{ t: Date.now(), a: 0, b: 0 }], variants: { a, b },
  };
  saveExperiments([exp, ...all]);
  return exp;
}

export const newVariant = (key: VariantKey, angle: string, content: string, hashtags: string): Variant => ({
  key, angle, content, hashtags, impressions: 0, clicks: 0, conversions: 0, paused: false,
});

function deviceOf(ua: string) {
  if (/iPhone|iPad|iOS/i.test(ua)) return 'iOS';
  if (/Android/i.test(ua)) return 'Android';
  return 'Desktop';
}

/** Called by the /go/:campaignId/:variant redirect page. Returns the real URL. */
export function recordClick(campaign: string, v: VariantKey, platform = 'direct'): string | null {
  const all = loadExperiments();
  const exp = all.find((e) => e.id === campaign);
  if (!exp) return null;
  exp.variants[v].clicks += 1;
  if (Math.random() < 0.3) exp.variants[v].conversions += 1;
  const last = exp.series[exp.series.length - 1];
  exp.series.push({ t: Date.now(), a: exp.variants.a.clicks, b: exp.variants.b.clicks });
  void last;
  saveExperiments(all);
  const clicks = listClicks();
  clicks.push({ id: crypto.randomUUID(), campaign, variant: v, at: Date.now(), platform, device: deviceOf(navigator.userAgent) });
  write(CLICKS, clicks.slice(-500));
  return destination(exp.promo_link, v);
}

/** Simulated traffic so active tests keep moving while you demo. */
export function simulateTraffic(): Experiment[] {
  const all = loadExperiments();
  all.forEach((e) => {
    if (e.status !== 'active') return;
    (['a', 'b'] as VariantKey[]).forEach((k) => {
      const v = e.variants[k];
      const bias = k === 'b' ? 1.18 : 1;
      v.impressions += Math.floor(8 + Math.random() * 14);
      const c = Math.random() < 0.06 * bias * 6 ? 1 : 0;
      v.clicks += c;
      if (c && Math.random() < 0.3) v.conversions += 1;
    });
    e.series.push({ t: Date.now(), a: e.variants.a.clicks, b: e.variants.b.clicks });
    if (e.series.length > 40) e.series.shift();
  });
  saveExperiments(all);
  return all;
}
