import { useCallback, useEffect, useRef, useState } from 'react';
import { AGENTS, type AgentId } from './agents';
import { db } from './db';

export type MemberId = AgentId | 'boss';
export type Place = 'office' | 'lab' | 'bar';
export type Phase = 'work' | 'meeting' | 'coffee';

export interface Idea {
  id: string;
  by: AgentId;
  text: string;
  verdict: string;
  at: number;
}

export const BOSS = {
  id: 'boss' as const,
  name: 'EmOrEj',
  role: 'Boss · Chief Orchestrator',
  color: '#f59e0b',
};

/* ------------------------------------------------------------------ *
 * Floor plan (percent of the office container, world 80 x 52 units)
 * ------------------------------------------------------------------ */
export interface Room { x: number; y: number; w: number; h: number }

export const ROOMS: Record<AgentId | 'boss' | 'lab' | 'bar', Room> = {
  // four private offices in the corners, with a wide hallway on each side
  aria: { x: 3, y: 3, w: 23, h: 38 },
  nova: { x: 3, y: 59, w: 23, h: 38 },
  blaze: { x: 74, y: 3, w: 23, h: 38 },
  cipher: { x: 74, y: 59, w: 23, h: 38 },
  // shared rooms down the middle, separated by cross-hallways
  boss: { x: 33, y: 3, w: 34, h: 24 },
  lab: { x: 33, y: 35, w: 34, h: 28 },
  bar: { x: 33, y: 71, w: 34, h: 26 },
};

type XY = { x: number; y: number };

const deskSpot = (id: AgentId): XY => ({ x: ROOMS[id].x + ROOMS[id].w / 2, y: ROOMS[id].y + ROOMS[id].h * 0.66 });

const LAB_SPOTS: Record<MemberId, XY> = {
  boss: { x: 50, y: 42 },
  aria: { x: 40, y: 47.5 },
  blaze: { x: 60, y: 47.5 },
  nova: { x: 40, y: 52 },
  cipher: { x: 60, y: 52 },
};

const BAR_SPOTS: Record<MemberId, XY> = {
  aria: { x: 41.5, y: 83.5 },
  nova: { x: 45.75, y: 83.5 },
  boss: { x: 50, y: 83.5 },
  blaze: { x: 54.25, y: 83.5 },
  cipher: { x: 58.5, y: 83.5 },
};

export function spotFor(id: MemberId, place: Place): XY {
  if (place === 'lab') return LAB_SPOTS[id];
  if (place === 'bar') return BAR_SPOTS[id];
  if (id === 'boss') return { x: 50, y: 15 };
  return deskSpot(id);
}

/* ------------------------------------------------------------------ *
 * Dialogue pools
 * ------------------------------------------------------------------ */
const IDEAS: Record<AgentId, string[]> = {
  aria: [
    'Gumawa tayo ng "Weekend Tournament" teaser na may countdown!',
    'Gawin nating meme-style ang hook ng leaderboard post.',
    'Mag-A/B test tayo: hype tone vs FOMO tone sa bagong game.',
    'Daily Challenge post series para laging may reason bumalik ang players.',
  ],
  blaze: [
    'Best engagement ay 7–9PM, doon natin i-schedule ang big posts.',
    'Cross-post sa Discord at Telegram 10 mins pagkatapos ng Facebook.',
    'Mag-reuse tayo ng top post bilang "Throwback Thursday".',
    'Gawin nating 3 posts/day lang para di mukhang spam.',
  ],
  nova: [
    'Auto-invite natin ang mga nag-comment ng "join" o "link".',
    'Welcome DM na may promo link para sa mga bagong player.',
    'Mag-target tayo ng gaming groups na active tuwing gabi.',
    'Gumawa ng referral invite: mag-invite ng friend, may reward.',
  ],
  cipher: [
    'Limit natin sa 12 invites/hour para iwas ban.',
    'I-pause ang variant B, mababa ang CTR niya.',
    'Mag-add tayo ng random delay para mukhang natural ang activity.',
    'Weekly report: top game, top platform, at best posting hour.',
  ],
};

const REACTIONS = ['Solid yan! 🔥', '+1 dito!', 'Noted, i-aayon ko ang plano ko.', 'Magandang idea, Boss!', 'Game ako diyan! 💪', 'Ayos! Pwede yan i-combine sa akin.'];

const VERDICTS = [
  'Approved ✅ — i-queue na natin yan ngayong linggo.',
  'Approved ✅ — Aria mag-draft, Blaze mag-schedule.',
  'Approved ✅ — i-test muna natin, tapos i-scale.',
];

const JOKES = [
  'Bakit pagod lagi ang server? 24/7 naka-duty, walang 13th month! 😅',
  'Anong paborito kong kape? Java-Script! ☕',
  'Bakit mabagal ang kape? Kasi mataas ang latte-ncy. 🐢',
  'Boss, kape po. — Sige, i-charge sa budget ng Brainstorm. 😂',
  'Bakit di nagugutom ang bot? Kasi laging may cache! 🍪',
  'Bakit di ngumingiti si Cipher? Rate-limited po siya. 😆',
  'Sabi ng bot sa kape: "Thanks, na-upgrade ako sa v2.0!" ⚡',
  'Bakit di nag-aaway ang mga bot? Kasi pareho silang naka-sync! 🤝',
];

const LAUGHS = ['HAHAHA 😂', 'Ang corny pero tawa pa rin ako 🤣', 'Hahaha, Boss ikaw talaga!', 'LOL 😆', 'Isa pa nga! 😄'];

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const shuffle = <T,>(arr: T[]): T[] => [...arr].sort(() => Math.random() - 0.5);

/* ------------------------------------------------------------------ *
 * Simulation hook
 * ------------------------------------------------------------------ */
const ALL_OFFICE: Record<MemberId, Place> = { boss: 'office', aria: 'office', blaze: 'office', nova: 'office', cipher: 'office' };

export function useOfficeSim(paused: Record<string, boolean>) {
  const [places, setPlaces] = useState<Record<MemberId, Place>>(ALL_OFFICE);
  const [speech, setSpeech] = useState<Partial<Record<MemberId, string>>>({});
  const [phase, setPhase] = useState<Phase>('work');
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const pausedRef = useRef(paused);
  pausedRef.current = paused;
  const queue = useRef<'brainstorm' | 'coffee' | null>(null);

  const trigger = useCallback((kind: 'brainstorm' | 'coffee') => {
    queue.current = kind;
  }, []);

  useEffect(() => {
    const token = { stop: false };
    setPlaces(ALL_OFFICE);
    setSpeech({});
    setPhase('work');

    const sleep = (ms: number) => new Promise<void>((res) => window.setTimeout(res, ms));
    const say = async (id: MemberId, text: string, ms = 3200) => {
      if (token.stop) return;
      setSpeech((p) => ({ ...p, [id]: text }));
      await sleep(ms);
      if (token.stop) return;
      setSpeech((p) => {
        if (p[id] !== text) return p;
        const n = { ...p };
        delete n[id];
        return n;
      });
    };
    const team = () => AGENTS.map((a) => a.id).filter((id) => !pausedRef.current[id]);
    const moveAll = (ids: MemberId[], place: Place) =>
      setPlaces((p) => {
        const n = { ...p };
        ids.forEach((i) => (n[i] = place));
        return n;
      });

    const brainstorm = async () => {
      const members = team();
      setPhase('meeting');
      await say('boss', 'Team, punta tayo sa Idea Lab! 💡', 2200);
      moveAll(['boss', ...members], 'lab');
      await sleep(4800);

      const proposed: Idea[] = [];
      for (const id of shuffle(members)) {
        if (token.stop) return;
        const text = pick(IDEAS[id]);
        await say(id, text, 3600);
        const others = (['boss', ...members] as MemberId[]).filter((m) => m !== id);
        await say(pick(others), pick(REACTIONS), 1700);
        proposed.push({ id: `${Date.now()}-${id}`, by: id, text, verdict: pick(VERDICTS), at: Date.now() });
      }
      if (token.stop) return;
      if (proposed.length > 0) {
        await say('boss', `Napakagandang session! ${proposed.length} idea${proposed.length > 1 ? 's' : ''} ang aprubado ko. ✅`, 3200);
        setIdeas((prev) => [...proposed.reverse(), ...prev].slice(0, 12));
        proposed.forEach((i) => void db.log('success', 'team', `Idea Lab: ${i.by} proposed "${i.text}" — approved by ${BOSS.name}`).catch(() => undefined));
      }
      await say('boss', 'Balik na sa kanya-kanyang office, team! 👏', 2200);
      moveAll(['boss', ...members], 'office');
      await sleep(4800);
      setPhase('work');
    };

    const coffee = async () => {
      const members = team();
      setPhase('coffee');
      await say('boss', 'Coffee break muna, team! ☕', 2200);
      moveAll(['boss', ...members], 'bar');
      await sleep(4800);
      for (let round = 0; round < 4; round++) {
        if (token.stop) return;
        const all = ['boss', ...members] as MemberId[];
        const speaker = pick(all);
        await say(speaker, pick(JOKES), 3800);
        await say(pick(all.filter((m) => m !== speaker)), pick(LAUGHS), 1600);
      }
      await say('boss', 'Okay, relax na! Balik na tayo sa trabaho! 💪', 2200);
      moveAll(['boss', ...members], 'office');
      await sleep(4800);
      setPhase('work');
    };

    void (async () => {
      let cycle = 0;
      await sleep(4000);
      while (!token.stop) {
        let waited = 0;
        while (!token.stop && waited < 22000 && !queue.current) {
          await sleep(500);
          waited += 500;
        }
        if (token.stop) break;
        const next = queue.current ?? (cycle % 2 === 0 ? 'brainstorm' : 'coffee');
        queue.current = null;
        cycle++;
        await (next === 'brainstorm' ? brainstorm() : coffee());
      }
    })();

    return () => {
      token.stop = true;
    };
  }, []);

  return { places, speech, phase, ideas, trigger };
}
