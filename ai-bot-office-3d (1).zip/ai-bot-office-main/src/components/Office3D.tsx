import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { AGENTS, type AgentId } from '@/lib/agents';
import type { AgentActivity } from '@/lib/useAgentActivity';
import { BOSS, ROOMS, type MemberId, type Phase, type Place, type Room } from '@/lib/office';

/* ------------------------------------------------------------------ *
 * World: 80 x 52 units. Percent positions from ROOMS map to world.
 * ------------------------------------------------------------------ */
const W = 80;
const D = 52;
const wx = (p: number) => ((p - 50) * W) / 100;
const wz = (p: number) => ((p - 50) * D) / 100;
const rb = (r: Room) => ({ x0: wx(r.x), x1: wx(r.x + r.w), z0: wz(r.y), z1: wz(r.y + r.h) });
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

const COLORS: Record<MemberId, string> = {
  boss: BOSS.color,
  aria: AGENTS[0].color,
  blaze: AGENTS[1].color,
  nova: AGENTS[2].color,
  cipher: AGENTS[3].color,
};
const IDS: MemberId[] = ['boss', 'aria', 'blaze', 'nova', 'cipher'];
const NAMES: Record<MemberId, string> = { boss: BOSS.name, aria: 'Aria', blaze: 'Blaze', nova: 'Nova', cipher: 'Cipher' };

/* ------------------------------------------------------------------ *
 * Seats & navigation graph
 * ------------------------------------------------------------------ */
const TABLE_C = new THREE.Vector3(0, 0, wz(49));
const LAB_SEATS: Record<MemberId, [number, number]> = {
  boss: [0, TABLE_C.z - 3.1],
  aria: [-5.4, TABLE_C.z - 1.1],
  nova: [-5.4, TABLE_C.z + 1.3],
  blaze: [5.4, TABLE_C.z - 1.1],
  cipher: [5.4, TABLE_C.z + 1.3],
};
const BAR_COUNTER_Z = wz(71) + 4.8;
const BAR_Z = BAR_COUNTER_Z + 1.8;
const BAR_SEATS: Record<MemberId, [number, number]> = {
  aria: [-6.8, BAR_Z],
  nova: [-3.4, BAR_Z],
  boss: [0, BAR_Z],
  blaze: [3.4, BAR_Z],
  cipher: [6.8, BAR_Z],
};

function officeDesk(id: MemberId) {
  if (id === 'boss') {
    const r = rb(ROOMS.boss);
    return { cx: 0, deskZ: r.z0 + 0.4 * (r.z1 - r.z0), seatZ: r.z0 + 0.4 * (r.z1 - r.z0) + 1.75 };
  }
  const r = rb(ROOMS[id]);
  const cx = (r.x0 + r.x1) / 2;
  const deskZ = r.z0 + 0.34 * (r.z1 - r.z0);
  return { cx, deskZ, seatZ: deskZ + 1.65 };
}

function spotOf(id: MemberId, place: Place): THREE.Vector3 {
  if (place === 'lab') return new THREE.Vector3(LAB_SEATS[id][0], 0, LAB_SEATS[id][1]);
  if (place === 'bar') return new THREE.Vector3(BAR_SEATS[id][0], 0, BAR_SEATS[id][1]);
  const d = officeDesk(id);
  return new THREE.Vector3(d.cx, 0, d.seatZ);
}

const NODE_PCT: Record<string, [number, number]> = {
  aD: [26, 22], nD: [26, 78], bD: [74, 22], cD: [74, 78], bossD: [50, 27],
  L1: [29.5, 22], L2: [29.5, 31], L3: [29.5, 49], L4: [29.5, 67], L5: [29.5, 78], L6: [29.5, 84],
  R1: [70.5, 22], R2: [70.5, 31], R3: [70.5, 49], R4: [70.5, 67], R5: [70.5, 78], R6: [70.5, 84],
  H1: [50, 31], H2: [50, 67],
  labL: [33, 49], labR: [67, 49], barL: [33, 84], barR: [67, 84],
};
const EDGES: [string, string][] = [
  ['aD', 'L1'], ['nD', 'L5'], ['bD', 'R1'], ['cD', 'R5'],
  ['L1', 'L2'], ['L2', 'L3'], ['L3', 'L4'], ['L4', 'L5'], ['L5', 'L6'],
  ['R1', 'R2'], ['R2', 'R3'], ['R3', 'R4'], ['R4', 'R5'], ['R5', 'R6'],
  ['L2', 'H1'], ['H1', 'R2'], ['L4', 'H2'], ['H2', 'R4'], ['bossD', 'H1'],
  ['L3', 'labL'], ['R3', 'labR'], ['L6', 'barL'], ['R6', 'barR'],
];
const NODES: Record<string, THREE.Vector3> = {};
Object.entries(NODE_PCT).forEach(([k, [x, y]]) => (NODES[k] = new THREE.Vector3(wx(x), 0, wz(y))));
const ADJ: Record<string, string[]> = {};
EDGES.forEach(([a, b]) => {
  (ADJ[a] ||= []).push(b);
  (ADJ[b] ||= []).push(a);
});

function entryNode(id: MemberId, place: Place): string {
  const left = id === 'aria' || id === 'nova' || id === 'boss';
  if (place === 'lab') return left ? 'labL' : 'labR';
  if (place === 'bar') return left ? 'barL' : 'barR';
  return { aria: 'aD', nova: 'nD', blaze: 'bD', cipher: 'cD', boss: 'bossD' }[id];
}

function nearestNode(p: THREE.Vector3): string {
  let best = 'L3';
  let bd = Infinity;
  for (const [k, v] of Object.entries(NODES)) {
    const d = (v.x - p.x) ** 2 + (v.z - p.z) ** 2;
    if (d < bd) { bd = d; best = k; }
  }
  return best;
}

function graphPath(from: string, to: string): string[] {
  const dist: Record<string, number> = { [from]: 0 };
  const prev: Record<string, string> = {};
  const todo = new Set(Object.keys(NODES));
  while (todo.size) {
    let u: string | null = null;
    todo.forEach((k) => { if (dist[k] !== undefined && (u === null || dist[k] < dist[u])) u = k; });
    if (u === null) break;
    todo.delete(u);
    if (u === to) break;
    for (const v of ADJ[u] ?? []) {
      const nd = dist[u] + NODES[u].distanceTo(NODES[v]);
      if (dist[v] === undefined || nd < dist[v]) { dist[v] = nd; prev[v] = u; }
    }
  }
  const out = [to];
  while (out[0] !== from && prev[out[0]]) out.unshift(prev[out[0]]);
  return out;
}

const LAB_DETOUR = () => new THREE.Vector3(-4.4, 0, TABLE_C.z - 3.4);

function routeTo(id: MemberId, from: THREE.Vector3, fromPlace: Place, place: Place, midWalk: boolean): THREE.Vector3[] {
  // leave through the door of the room we were in (or the nearest node if we were already walking)
  const start = midWalk ? nearestNode(from) : entryNode(id, fromPlace);
  const end = entryNode(id, place);
  const pts: THREE.Vector3[] = [];
  if (id === 'boss' && fromPlace === 'lab' && !midWalk) pts.push(LAB_DETOUR());
  graphPath(start, end).forEach((k) => pts.push(NODES[k].clone()));
  if (id === 'boss' && place === 'lab') pts.push(LAB_DETOUR());
  pts.push(spotOf(id, place));
  return pts;
}

/* ------------------------------------------------------------------ *
 * Mesh helpers
 * ------------------------------------------------------------------ */
const mat = (color: THREE.ColorRepresentation, rough = 0.7, metal = 0.05) =>
  new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
const glowMat = (color: THREE.ColorRepresentation, intensity = 1.2) =>
  new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: intensity, roughness: 0.4 });

function box(parent: THREE.Object3D, w: number, h: number, d: number, m: THREE.Material, x = 0, y = 0, z = 0, shadow = true) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = shadow;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}
function cyl(parent: THREE.Object3D, rt: number, rb2: number, h: number, m: THREE.Material, x = 0, y = 0, z = 0, seg = 20) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb2, h, seg), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}
function sphere(parent: THREE.Object3D, r: number, m: THREE.Material, x = 0, y = 0, z = 0) {
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(r, 16, 12), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  parent.add(mesh);
  return mesh;
}

function canvasTex(w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) {
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const c = cv.getContext('2d')!;
  draw(c);
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return { cv, c, t };
}

/* ------------------------------------------------------------------ *
 * Furniture
 * ------------------------------------------------------------------ */
interface Screen { c: CanvasRenderingContext2D; t: THREE.CanvasTexture; color: string }

function makeDesk(parent: THREE.Object3D, x: number, z: number, accent: string, dual: boolean, screens: Screen[]) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  const wood = mat(dual ? '#6b4423' : '#5a3d2b', 0.55);
  const w = dual ? 4.6 : 3.4;
  box(g, w, 0.14, 1.7, wood, 0, 1.05, 0);
  box(g, 0.14, 1.0, 1.6, mat('#2a1b13'), -w / 2 + 0.1, 0.5, 0);
  box(g, 0.14, 1.0, 1.6, mat('#2a1b13'), w / 2 - 0.1, 0.5, 0);
  box(g, w - 0.3, 0.7, 0.08, mat('#2a1b13'), 0, 0.65, -0.7);
  box(g, w, 0.035, 0.035, glowMat(accent, 1.6), 0, 0.98, 0.86, false);
  const monX = dual ? [-1.2, 1.2] : [0];
  monX.forEach((mx) => {
    cyl(g, 0.09, 0.09, 0.42, mat('#15181f', 0.4, 0.6), mx, 1.33, -0.35);
    cyl(g, 0.4, 0.45, 0.05, mat('#15181f', 0.4, 0.6), mx, 1.14, -0.35);
    box(g, 1.75, 1.0, 0.07, mat('#0c0f15', 0.3, 0.5), mx, 2.0, -0.4);
    const { c, t } = canvasTex(192, 108, () => undefined);
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(1.65, 0.9), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
    screen.position.set(mx, 2.0, -0.36);
    g.add(screen);
    screens.push({ c, t, color: accent });
  });
  box(g, 1.1, 0.04, 0.38, mat('#10141c', 0.4, 0.4), 0, 1.14, 0.4);
  box(g, 1.1, 0.012, 0.38, glowMat(accent, 0.9), 0, 1.165, 0.4, false);
  box(g, 0.2, 0.05, 0.3, mat('#10141c'), 1.0, 1.14, 0.45);
  cyl(g, 0.12, 0.1, 0.24, mat('#f3f4f6', 0.4), w / 2 - 0.5, 1.24, 0.1);
  // desk lamp
  cyl(g, 0.16, 0.2, 0.05, mat('#222833'), -w / 2 + 0.45, 1.15, -0.2);
  cyl(g, 0.025, 0.025, 0.7, mat('#222833'), -w / 2 + 0.45, 1.5, -0.2);
  const head = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.28, 16), glowMat('#ffd9a0', 1.1));
  head.position.set(-w / 2 + 0.6, 1.88, -0.1);
  head.rotation.z = 0.5;
  g.add(head);
  parent.add(g);
}

function makeChair(parent: THREE.Object3D, x: number, z: number, color: string, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  const m = mat(color, 0.8);
  box(g, 1.15, 0.16, 1.1, m, 0, 0.85, 0);
  box(g, 1.1, 1.15, 0.14, m, 0, 1.45, 0.55);
  cyl(g, 0.07, 0.07, 0.6, mat('#0c0f15', 0.3, 0.7), 0, 0.5, 0);
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    box(g, 0.7, 0.06, 0.1, mat('#0c0f15', 0.3, 0.7), Math.cos(a) * 0.3, 0.22, Math.sin(a) * 0.3).rotation.y = -a;
  }
  parent.add(g);
}

function makePlant(parent: THREE.Object3D, x: number, z: number, s = 1) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.scale.setScalar(s);
  cyl(g, 0.5, 0.38, 0.8, mat('#e5e7eb', 0.5), 0, 0.4, 0);
  cyl(g, 0.46, 0.46, 0.05, mat('#3b2a1c'), 0, 0.8, 0);
  const greens = ['#2f9e5a', '#3fb86d', '#238a4a'];
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2;
    const leaf = sphere(g, 0.42, mat(greens[i % 3], 0.8), Math.cos(a) * 0.35, 1.3 + (i % 3) * 0.3, Math.sin(a) * 0.35);
    leaf.scale.set(1, 1.5, 0.7);
    leaf.rotation.y = a;
  }
  parent.add(g);
}

function makeShelf(parent: THREE.Object3D, x: number, z: number, rotY = 0, w = 2.8) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  const m = mat('#3b2a1e', 0.6);
  box(g, w, 3.4, 0.6, m, 0, 1.7, 0);
  for (let s = 0; s < 4; s++) {
    box(g, w - 0.2, 0.06, 0.55, mat('#4b3626'), 0, 0.4 + s * 0.8, 0.02);
    let px = -w / 2 + 0.25;
    while (px < w / 2 - 0.35) {
      const bw = 0.12 + Math.random() * 0.16;
      const bh = 0.45 + Math.random() * 0.25;
      box(g, bw, bh, 0.4, mat(new THREE.Color().setHSL(Math.random(), 0.55, 0.45)), px + bw / 2, 0.43 + s * 0.8 + bh / 2, 0.06, false);
      px += bw + 0.03;
    }
  }
  parent.add(g);
}

function makeSofa(parent: THREE.Object3D, x: number, z: number, rotY: number, color: string, w = 3.6) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  const m = mat(color, 0.9);
  box(g, w, 0.7, 1.4, m, 0, 0.55, 0);
  box(g, w, 1.1, 0.35, m, 0, 1.25, -0.55);
  box(g, 0.35, 0.95, 1.4, m, -w / 2 + 0.17, 0.95, 0);
  box(g, 0.35, 0.95, 1.4, m, w / 2 - 0.17, 0.95, 0);
  box(g, w - 0.8, 0.22, 1.0, mat(color, 0.95), 0, 1.0, 0.1);
  parent.add(g);
}

function makeCabinet(parent: THREE.Object3D, x: number, z: number, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, 1.3, 2.0, 0.8, mat('#5b6577', 0.5, 0.3), 0, 1.0, 0);
  [0.5, 1.0, 1.5].forEach((y) => box(g, 0.5, 0.06, 0.04, mat('#cbd5e1', 0.3, 0.8), 0, y, 0.42, false));
  parent.add(g);
}

function makeRug(parent: THREE.Object3D, x: number, z: number, w: number, d: number, color: string) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.04, d), mat(color, 1));
  m.position.set(x, 0.07, z);
  m.receiveShadow = true;
  parent.add(m);
  const edge = new THREE.Mesh(new THREE.BoxGeometry(w - 0.4, 0.045, d - 0.4), mat(new THREE.Color(color).multiplyScalar(0.7), 1));
  edge.position.set(x, 0.075, z);
  parent.add(edge);
}

function makeArt(parent: THREE.Object3D, x: number, y: number, z: number, w: number, h: number, hue: number, rotY = 0) {
  const { t } = canvasTex(128, 128, (c) => {
    const g = c.createLinearGradient(0, 0, 128, 128);
    g.addColorStop(0, `hsl(${hue},70%,55%)`);
    g.addColorStop(1, `hsl(${(hue + 60) % 360},70%,30%)`);
    c.fillStyle = g;
    c.fillRect(0, 0, 128, 128);
    c.fillStyle = 'rgba(255,255,255,0.18)';
    c.beginPath(); c.arc(80, 50, 30, 0, 6.28); c.fill();
    c.fillRect(10, 90, 100, 14);
  });
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = rotY;
  box(g, w + 0.12, h + 0.12, 0.08, mat('#111827'), 0, 0, 0, false);
  const p = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t }));
  p.position.z = 0.05;
  g.add(p);
  parent.add(g);
}

function rbox(parent: THREE.Object3D, w: number, h: number, d: number, r: number, m: THREE.Material, x = 0, y = 0, z = 0, shadow = true) {
  const mesh = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 3, r), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = shadow;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function makeRunner(parent: THREE.Object3D, x: number, z: number, w: number, d: number, color: string) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.03, d), mat(color, 1));
  m.position.set(x, 0.02, z);
  m.receiveShadow = true;
  parent.add(m);
}

function makeGuide(parent: THREE.Object3D, x: number, z: number, w: number, d: number, color: string) {
  box(parent, w, 0.02, d, glowMat(color, 1.2), x, 0.045, z, false);
}

function makeCoffeeTable(parent: THREE.Object3D, x: number, z: number, w = 2.6, d = 1.3, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, w, 0.1, d, mat('#d9c7a6', 0.4), 0, 0.72, 0);
  ([[-1, -1], [1, -1], [-1, 1], [1, 1]] as [number, number][]).forEach(([sx, sz]) =>
    box(g, 0.08, 0.7, 0.08, mat('#222833', 0.4, 0.6), sx * (w / 2 - 0.15), 0.35, sz * (d / 2 - 0.15), false));
  cyl(g, 0.12, 0.1, 0.18, mat('#ffffff', 0.4), -w * 0.2, 0.85, 0);
  box(g, 0.5, 0.04, 0.35, mat('#38bdf8', 0.5), w * 0.15, 0.79, 0.05, false);
  parent.add(g);
}

function makeFloorLamp(parent: THREE.Object3D, x: number, z: number, color = '#ffd9a0') {
  cyl(parent, 0.28, 0.3, 0.06, mat('#222833', 0.4, 0.6), x, 0.03, z);
  cyl(parent, 0.04, 0.04, 3.0, mat('#222833', 0.4, 0.6), x, 1.5, z, 8);
  const shade = new THREE.Mesh(
    new THREE.CylinderGeometry(0.3, 0.42, 0.55, 16, 1, true),
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.9, side: THREE.DoubleSide }),
  );
  shade.position.set(x, 3.1, z);
  parent.add(shade);
}

function makeCooler(parent: THREE.Object3D, x: number, z: number, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, 0.9, 1.5, 0.9, mat('#e5e7eb', 0.4), 0, 0.75, 0);
  cyl(g, 0.34, 0.34, 0.85, new THREE.MeshPhysicalMaterial({ color: '#93c5fd', transparent: true, opacity: 0.55, roughness: 0.1 }), 0, 1.95, 0);
  box(g, 0.16, 0.1, 0.04, glowMat('#38bdf8', 1.4), -0.17, 1.2, 0.46, false);
  box(g, 0.16, 0.1, 0.04, glowMat('#f87171', 1.4), 0.17, 1.2, 0.46, false);
  parent.add(g);
}

function makePrinter(parent: THREE.Object3D, x: number, z: number, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, 2.0, 1.0, 1.2, mat('#374151', 0.5, 0.3), 0, 0.5, 0);
  rbox(g, 1.6, 0.6, 1.0, 0.1, mat('#e5e7eb', 0.4, 0.1), 0, 1.3, 0);
  box(g, 1.2, 0.05, 0.7, mat('#0b0f17'), 0, 1.62, 0.05, false);
  box(g, 0.35, 0.07, 0.04, glowMat('#34d399', 1.6), 0.5, 1.38, 0.52, false);
  parent.add(g);
}

function makeRack(parent: THREE.Object3D, x: number, z: number, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, 1.3, 3.2, 1.1, mat('#12161f', 0.4, 0.5), 0, 1.6, 0);
  const leds = ['#34d399', '#38bdf8', '#fbbf24'];
  for (let i = 0; i < 8; i++) {
    box(g, 1.1, 0.18, 0.04, mat('#1c2230', 0.4, 0.5), 0, 0.4 + i * 0.36, 0.56, false);
    for (let k = 0; k < 3; k++) box(g, 0.06, 0.06, 0.03, glowMat(leds[(i + k) % 3], 1.6), -0.35 + k * 0.14, 0.4 + i * 0.36, 0.59, false);
  }
  parent.add(g);
}

function makeDeskPlant(parent: THREE.Object3D, x: number, y: number, z: number, s = 1) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.scale.setScalar(s);
  cyl(g, 0.22, 0.17, 0.3, mat('#f3f4f6', 0.5), 0, 0.15, 0);
  ([[0, 0.55, 0], [0.14, 0.45, 0.05], [-0.14, 0.48, -0.04]] as [number, number, number][]).forEach(([px, py, pz]) =>
    sphere(g, 0.18, mat('#2f9e5a', 0.8), px, py, pz));
  parent.add(g);
}

function makeBoard(parent: THREE.Object3D, x: number, y: number, z: number, w: number, h: number, rotY: number, title: string, color: string, chart = false) {
  const { t } = canvasTex(512, 256, (c) => {
    c.fillStyle = '#f8fafc';
    c.fillRect(0, 0, 512, 256);
    c.fillStyle = color;
    c.fillRect(0, 0, 512, 46);
    c.fillStyle = '#ffffff';
    c.font = 'bold 28px sans-serif';
    c.fillText(title, 16, 34);
    if (chart) {
      [60, 110, 80, 150, 120, 170, 140].forEach((bh, i) => {
        c.fillStyle = i % 2 ? color : '#94a3b8';
        c.fillRect(40 + i * 62, 232 - bh * 0.95, 40, bh * 0.95);
      });
    } else {
      ['#fde68a', '#fbcfe8', '#bae6fd', '#bbf7d0', '#fed7aa', '#ddd6fe'].forEach((col, i) => {
        const nx = 24 + (i % 3) * 160;
        const ny = 66 + Math.floor(i / 3) * 94;
        c.fillStyle = col;
        c.fillRect(nx, ny, 140, 80);
        c.fillStyle = '#94a3b8';
        c.fillRect(nx + 12, ny + 20, 90, 5);
        c.fillRect(nx + 12, ny + 38, 64, 5);
      });
    }
  });
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = rotY;
  box(g, w + 0.2, h + 0.2, 0.08, mat('#cbd5e1', 0.3, 0.6), 0, 0, 0, false);
  const p = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
  p.position.z = 0.05;
  g.add(p);
  parent.add(g);
}

function makeNeon(parent: THREE.Object3D, x: number, y: number, z: number, w: number, h: number, text: string, glow: string, fill = '#fff7e6') {
  const hpx = Math.round((512 * h) / w);
  const { t } = canvasTex(512, hpx, (c) => {
    c.fillStyle = '#0b0e14';
    c.fillRect(0, 0, 512, hpx);
    c.shadowColor = glow;
    c.shadowBlur = 24;
    c.fillStyle = fill;
    c.font = `bold ${Math.round(hpx * 0.55)}px sans-serif`;
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(text, 256, hpx / 2 + 3);
  });
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
  m.position.set(x, y, z);
  parent.add(m);
}

/* ------------------------------------------------------------------ *
 * Walls with door gaps
 * ------------------------------------------------------------------ */
type Gap = { at: number; w: number };
function wallLine(parent: THREE.Object3D, x0: number, z0: number, x1: number, z1: number, gaps: Gap[], tint: string) {
  const horizontal = Math.abs(z1 - z0) < 1e-6;
  const L = horizontal ? x1 - x0 : z1 - z0;
  const sorted = [...gaps].sort((a, b) => a.at - b.at);
  const pieces: [number, number][] = [];
  let cur = 0;
  sorted.forEach((g) => {
    if (g.at - g.w / 2 > cur) pieces.push([cur, g.at - g.w / 2]);
    cur = g.at + g.w / 2;
  });
  if (cur < L) pieces.push([cur, L]);
  const base = mat('#1d2432', 0.5, 0.2);
  const rail = mat(tint, 0.4, 0.5);
  const glass = new THREE.MeshPhysicalMaterial({ color: '#a8d4ff', transparent: true, opacity: 0.16, roughness: 0.05, metalness: 0, side: THREE.DoubleSide, depthWrite: false });
  pieces.forEach(([a, b]) => {
    const len = b - a;
    if (len < 0.05) return;
    const mid = (a + b) / 2;
    const cx = horizontal ? x0 + mid : x0;
    const cz = horizontal ? z0 : z0 + mid;
    const sx = horizontal ? len : 0.3;
    const sz = horizontal ? 0.3 : len;
    box(parent, sx, 0.8, sz, base, cx, 0.4, cz);
    const gl = new THREE.Mesh(new THREE.BoxGeometry(horizontal ? len : 0.06, 2.3, horizontal ? 0.06 : len), glass);
    gl.position.set(cx, 1.95, cz);
    parent.add(gl);
    box(parent, sx, 0.12, sz, rail, cx, 3.14, cz, false);
  });
  // posts at every piece end
  pieces.forEach(([a, b]) => [a, b].forEach((t) => {
    box(parent, 0.3, 3.2, 0.3, rail, horizontal ? x0 + t : x0, 1.6, horizontal ? z0 : z0 + t);
  }));
}

function doorLight(parent: THREE.Object3D, x: number, z: number, horizontalDoor: boolean, w: number, color: string) {
  box(parent, horizontalDoor ? w : 0.18, 0.1, horizontalDoor ? 0.18 : w, glowMat(color, 1.8), x, 3.0, z, false);
}

/* ------------------------------------------------------------------ *
 * Characters
 * ------------------------------------------------------------------ */
interface Bot {
  id: MemberId;
  group: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  cup: THREE.Mesh;
  eyes: THREE.Mesh[];
  spin: THREE.Object3D[];
  orb: THREE.Mesh | null;
  pos: THREE.Vector3;
  path: THREE.Vector3[];
  place: Place;
  yaw: number;
  walking: boolean;
}

function makeBot(id: MemberId): Bot {
  const color = COLORS[id];
  const boss = id === 'boss';
  const g = new THREE.Group();
  g.userData.id = id;
  g.scale.setScalar(boss ? 1.22 : 1.15);

  const suit = new THREE.MeshStandardMaterial({
    color: boss ? '#241a14' : new THREE.Color(color).multiplyScalar(0.42),
    roughness: 0.45,
    metalness: 0.25,
  });
  const shell = new THREE.MeshPhysicalMaterial({ color: '#eef2f8', roughness: 0.25, metalness: 0.35, clearcoat: 0.8, clearcoatRoughness: 0.2 });
  const metal = mat('#cfd6e2', 0.3, 0.7);
  const dark = mat('#0b0f17', 0.4, 0.3);
  const pants = mat('#1b2130', 0.6, 0.1);
  const gloss = new THREE.MeshStandardMaterial({ color: '#05080f', roughness: 0.12, metalness: 0.75 });
  const trim = mat(boss ? '#fbbf24' : color, 0.3, 0.7);
  const gold = mat('#fbbf24', 0.25, 0.9);
  const eyes: THREE.Mesh[] = [];
  const spin: THREE.Object3D[] = [];
  let orb: THREE.Mesh | null = null;

  // torso, pelvis, belt
  rbox(g, 1.02, 1.1, 0.62, 0.2, suit, 0, 1.52, 0);
  rbox(g, 0.9, 0.3, 0.56, 0.1, dark, 0, 0.98, 0);
  rbox(g, 1.04, 0.1, 0.66, 0.04, trim, 0, 1.1, 0, false);
  rbox(g, 0.2, 0.14, 0.05, 0.03, boss ? gold : glowMat(color, 1.4), 0, 1.1, 0.33, false);
  // shoulders
  sphere(g, 0.2, suit, -0.66, 1.95, 0);
  sphere(g, 0.2, suit, 0.66, 1.95, 0);
  // chest emblem
  if (id === 'cipher') {
    const sh = new THREE.Shape();
    sh.moveTo(-0.2, 0.2); sh.lineTo(0.2, 0.2); sh.lineTo(0.2, -0.04);
    sh.quadraticCurveTo(0.2, -0.2, 0, -0.3);
    sh.quadraticCurveTo(-0.2, -0.2, -0.2, -0.04);
    sh.closePath();
    const shield = new THREE.Mesh(new THREE.ExtrudeGeometry(sh, { depth: 0.04, bevelEnabled: false }), glowMat(color, 1.8));
    shield.position.set(0, 1.68, 0.31);
    g.add(shield);
  } else if (boss) {
    rbox(g, 0.2, 0.15, 0.05, 0.04, mat('#b91c1c', 0.5), 0, 1.96, 0.33, false);
    rbox(g, 0.18, 0.62, 0.04, 0.03, mat('#b91c1c', 0.5), 0, 1.58, 0.33, false);
    sphere(g, 0.07, gold, -0.3, 1.78, 0.32);
    rbox(g, 0.34, 0.08, 0.3, 0.03, gold, -0.62, 2.1, 0);
    rbox(g, 0.34, 0.08, 0.3, 0.03, gold, 0.62, 2.1, 0);
  } else {
    const core = cyl(g, 0.14, 0.14, 0.05, glowMat(color, 2), 0, 1.62, 0.32);
    core.rotation.x = Math.PI / 2;
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.025, 8, 24), metal);
    ring.position.set(0, 1.62, 0.32);
    g.add(ring);
  }
  // collar + neck
  cyl(g, 0.3, 0.34, 0.1, trim, 0, 2.03, 0);
  cyl(g, 0.14, 0.14, 0.2, dark, 0, 2.1, 0);

  // head
  rbox(g, 1.08, 0.86, 0.92, 0.3, shell, 0, 2.55, 0);
  rbox(g, 0.9, 0.5, 0.1, 0.2, gloss, 0, 2.54, 0.43, false);
  [-0.2, 0.2].forEach((ex) => eyes.push(rbox(g, 0.17, 0.2, 0.05, 0.06, glowMat(color, 2.6), ex, 2.58, 0.5, false)));
  const smile = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.016, 6, 14, Math.PI), glowMat(color, 1.8));
  smile.rotation.z = Math.PI;
  smile.position.set(0, 2.46, 0.5);
  g.add(smile);
  [-1, 1].forEach((sx) => {
    cyl(g, 0.2, 0.2, 0.14, mat(color, 0.35, 0.6), sx * 0.6, 2.55, 0).rotation.z = Math.PI / 2;
    cyl(g, 0.1, 0.1, 0.17, glowMat(color, 1.2), sx * 0.6, 2.55, 0).rotation.z = Math.PI / 2;
  });

  // role accessories
  if (boss) {
    cyl(g, 0.4, 0.36, 0.2, gold, 0, 3.08, 0, 16);
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const px = Math.cos(a) * 0.36;
      const pz = Math.sin(a) * 0.36;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.34, 6), gold);
      spike.position.set(px, 3.33, pz);
      spike.castShadow = true;
      g.add(spike);
      sphere(g, 0.05, glowMat(i % 2 ? '#ef4444' : '#38bdf8', 1.6), px, 3.54, pz);
    }
    sphere(g, 0.07, glowMat('#ef4444', 2), 0, 3.08, 0.4);
    const mono = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.018, 8, 20), gold);
    mono.position.set(0.2, 2.58, 0.5);
    g.add(mono);
    rbox(g, 1.15, 1.7, 0.05, 0.02, mat('#7f1d1d', 0.7), 0, 1.35, -0.34, false);
  } else if (id === 'aria') {
    const beret = cyl(g, 0.52, 0.5, 0.14, mat('#047857', 0.8), -0.06, 3.02, 0, 20);
    beret.rotation.z = 0.12;
    orb = sphere(g, 0.09, glowMat(color, 2.4), -0.06, 3.15, 0);
    const pen = cyl(g, 0.035, 0.035, 0.55, mat('#fbbf24', 0.5), 0.45, 3.1, -0.05, 8);
    pen.rotation.z = -0.35;
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.1, 8), mat('#f472b6', 0.5));
    tip.position.set(0.55, 3.38, -0.05);
    tip.rotation.z = -0.35;
    g.add(tip);
  } else if (id === 'blaze') {
    cyl(g, 0.04, 0.04, 0.3, metal, 0, 3.1, 0, 8);
    const pivot = new THREE.Group();
    pivot.position.set(0, 3.3, 0);
    g.add(pivot);
    spin.push(pivot);
    const dish = new THREE.Mesh(
      new THREE.SphereGeometry(0.4, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2),
      new THREE.MeshStandardMaterial({ color: '#e5e7eb', roughness: 0.3, metalness: 0.6, side: THREE.DoubleSide }),
    );
    dish.rotation.x = Math.PI - 0.5;
    dish.castShadow = true;
    pivot.add(dish);
    orb = sphere(pivot, 0.07, glowMat(color, 2.4), 0, 0.3, -0.08);
  } else if (id === 'nova') {
    const arch = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.045, 8, 28, Math.PI), mat('#1b2130', 0.4, 0.5));
    arch.position.set(0, 2.45, 0);
    g.add(arch);
    const a = new THREE.Vector3(0.6, 2.42, 0.1);
    const b = new THREE.Vector3(0.28, 2.3, 0.52);
    const boom = cyl(g, 0.025, 0.025, a.distanceTo(b), mat('#1b2130', 0.4, 0.5), 0, 0, 0, 8);
    boom.position.copy(a).add(b).multiplyScalar(0.5);
    boom.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.clone().sub(a).normalize());
    sphere(g, 0.07, glowMat(color, 2), b.x, b.y, b.z);
    cyl(g, 0.03, 0.03, 0.35, metal, 0, 3.15, 0, 8);
    orb = sphere(g, 0.1, glowMat(color, 2.4), 0, 3.42, 0);
    const pivot = new THREE.Group();
    pivot.position.set(0, 3.42, 0);
    g.add(pivot);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.015, 6, 24), glowMat(color, 1.4));
    ring.rotation.x = Math.PI / 2 + 0.5;
    pivot.add(ring);
    spin.push(pivot);
  } else {
    [0.3, 0.44, 0.3].forEach((h, i) => {
      const fin = new THREE.Mesh(new THREE.ConeGeometry(0.1, h, 6), glowMat(color, 1.6));
      fin.position.set(0, 2.98 + h / 2 - 0.02, (i - 1) * 0.24);
      g.add(fin);
    });
  }

  // legs and arms pivot at hip / shoulder
  const mkLimb = (x: number, y: number, len: number, rad: number, m: THREE.Material) => {
    const l = new THREE.Group();
    l.position.set(x, y, 0);
    const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(rad, Math.max(0.01, len - rad * 2), 4, 10), m);
    mesh.position.y = -len / 2;
    mesh.castShadow = true;
    l.add(mesh);
    g.add(l);
    return l;
  };
  const legL = mkLimb(-0.28, 0.98, 0.95, 0.17, pants);
  const legR = mkLimb(0.28, 0.98, 0.95, 0.17, pants);
  const armL = mkLimb(-0.66, 1.95, 0.85, 0.12, suit);
  const armR = mkLimb(0.66, 1.95, 0.85, 0.12, suit);
  const shoe = mat(boss ? '#120d0a' : '#e5e7eb', 0.4, 0.2);
  [legL, legR].forEach((l) => rbox(l, 0.4, 0.2, 0.58, 0.09, shoe, 0, -0.93, 0.09));
  [armL, armR].forEach((a) => sphere(a, 0.15, shell, 0, -0.85, 0));
  const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.11, 0.26, 12), mat('#ffffff', 0.4));
  cup.position.set(0, -0.9, 0.12);
  cup.visible = false;
  armR.add(cup);

  // back plate with the member's name (the camera mostly sees bots from behind)
  const plate = canvasTex(256, 96, (c) => {
    c.clearRect(0, 0, 256, 96);
    c.fillStyle = 'rgba(8,12,20,0.92)';
    c.beginPath();
    c.roundRect(4, 4, 248, 88, 22);
    c.fill();
    c.strokeStyle = color;
    c.lineWidth = 5;
    c.stroke();
    c.fillStyle = boss ? '#fde68a' : '#f8fafc';
    c.font = 'bold 54px sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(NAMES[id], 128, 52);
  });
  const pm = new THREE.Mesh(new THREE.PlaneGeometry(0.82, 0.31), new THREE.MeshBasicMaterial({ map: plate.t, transparent: true, toneMapped: false }));
  pm.position.set(0, 1.72, boss ? -0.38 : -0.325);
  pm.rotation.y = Math.PI;
  g.add(pm);
  [-0.3, 0.3].forEach((sx) => box(g, 0.05, 0.45, 0.03, glowMat(color, 1.4), sx, 1.2, -0.325, false));

  return { id, group: g, legL, legR, armL, armR, cup, eyes, spin, orb, pos: new THREE.Vector3(), path: [], place: 'office', yaw: Math.PI, walking: false };
}

/* ------------------------------------------------------------------ *
 * Component
 * ------------------------------------------------------------------ */
interface Props {
  activity: Record<AgentId, AgentActivity>;
  places: Record<MemberId, Place>;
  speech: Partial<Record<MemberId, string>>;
  phase: Phase;
  isNight: boolean;
  onSelect: (id: AgentId) => void;
  onBossClick: () => void;
}

const ROOM_LABELS: { key: string; text: string; sub: string; color: string; x: number; z: number }[] = [];

export default function Office3D({ activity, places, speech, phase, isNight, onSelect, onBossClick }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const tagRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const roomRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const live = useRef({ activity, places, phase, isNight, onSelect, onBossClick });
  live.current = { activity, places, phase, isNight, onSelect, onBossClick };

  if (ROOM_LABELS.length === 0) {
    AGENTS.forEach((a) => {
      const r = rb(ROOMS[a.id]);
      ROOM_LABELS.push({ key: a.id, text: `🔒 ${a.name}'s Office`, sub: a.role, color: a.color, x: (r.x0 + r.x1) / 2, z: r.z0 });
    });
    const bo = rb(ROOMS.boss);
    ROOM_LABELS.push({ key: 'boss', text: '👑 Boss Office', sub: `${BOSS.name} · ${BOSS.role}`, color: BOSS.color, x: 0, z: bo.z0 });
    ROOM_LABELS.push({ key: 'lab', text: '💡 Idea Lab', sub: 'Brainstorm room', color: '#a78bfa', x: 0, z: rb(ROOMS.lab).z0 });
    ROOM_LABELS.push({ key: 'bar', text: '☕ Mini Bar', sub: 'Kape at kwentuhan', color: '#fb923c', x: 0, z: rb(ROOMS.bar).z1 });
  }

  useEffect(() => {
    const host = hostRef.current!;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.5, 300);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    host.prepend(renderer.domElement);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 0, 1.5);
    controls.enablePan = false;
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minPolarAngle = 0.35;
    controls.maxPolarAngle = 1.2;
    controls.minAzimuthAngle = -0.85;
    controls.maxAzimuthAngle = 0.85;
    controls.minDistance = 24;
    controls.maxDistance = 150;

    /* ---- lights ---- */
    const hemi = new THREE.HemisphereLight('#dbe8ff', '#202636', 0.9);
    scene.add(hemi);
    const sun = new THREE.DirectionalLight('#fff1d6', 1.5);
    sun.position.set(-26, 62, 36);
    sun.castShadow = true;
    const shadowRes = window.innerWidth < 700 ? 2048 : 4096;
    sun.shadow.mapSize.set(shadowRes, shadowRes);
    sun.shadow.camera.left = -54;
    sun.shadow.camera.right = 54;
    sun.shadow.camera.top = 44;
    sun.shadow.camera.bottom = -44;
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 170;
    sun.shadow.bias = -0.0004;
    scene.add(sun);
    const roomLights: THREE.PointLight[] = [];
    const addRoomLight = (x: number, z: number, color: string) => {
      const l = new THREE.PointLight(color, 0, 36, 1.5);
      l.position.set(x, 5.5, z);
      scene.add(l);
      roomLights.push(l);
    };

    /* ---- floor & building shell ---- */
    const floorTex = canvasTex(512, 512, (c) => {
      c.fillStyle = '#222a38';
      c.fillRect(0, 0, 512, 512);
      c.strokeStyle = 'rgba(255,255,255,0.06)';
      c.lineWidth = 2;
      for (let i = 0; i <= 512; i += 64) { c.beginPath(); c.moveTo(i, 0); c.lineTo(i, 512); c.stroke(); c.beginPath(); c.moveTo(0, i); c.lineTo(512, i); c.stroke(); }
    });
    floorTex.t.wrapS = floorTex.t.wrapT = THREE.RepeatWrapping;
    floorTex.t.repeat.set(21, 14);
    const floor = new THREE.Mesh(new THREE.BoxGeometry(W + 4, 0.4, D + 4), new THREE.MeshStandardMaterial({ map: floorTex.t, roughness: 0.35, metalness: 0.2 }));
    floor.position.y = -0.2;
    floor.receiveShadow = true;
    scene.add(floor);
    box(scene, W + 5, 0.3, 0.5, mat('#0d111a'), 0, 0.1, D / 2 + 2.2);
    // skyline back wall
    const sky = canvasTex(2048, 256, (c) => {
      const g = c.createLinearGradient(0, 0, 0, 256);
      g.addColorStop(0, '#2c6cc4');
      g.addColorStop(1, '#bcd8ff');
      c.fillStyle = g;
      c.fillRect(0, 0, 2048, 256);
      for (let i = 0; i < 52; i++) {
        const bw = 30 + Math.random() * 50;
        const bh = 60 + Math.random() * 130;
        const bx = i * 40 + Math.random() * 10;
        c.fillStyle = `rgb(${50 + Math.random() * 30},${64 + Math.random() * 30},${96 + Math.random() * 30})`;
        c.fillRect(bx, 256 - bh, bw, bh);
        c.fillStyle = 'rgba(255,225,150,0.85)';
        for (let y = 256 - bh + 8; y < 250; y += 14) for (let x = bx + 5; x < bx + bw - 6; x += 12) if (Math.random() > 0.55) c.fillRect(x, y, 5, 7);
      }
    });
    const skyMat = new THREE.MeshBasicMaterial({ map: sky.t, toneMapped: false });
    const back = new THREE.Mesh(new THREE.PlaneGeometry(W + 4, 16), skyMat);
    back.position.set(0, 8.5, -D / 2 - 2);
    scene.add(back);
    box(scene, W + 4, 0.3, 0.4, mat('#0d111a'), 0, 0.4, -D / 2 - 1.9);

    /* ---- rooms ---- */
    const screens: Record<string, Screen[]> = {};
    const addRoom = (key: AgentId | 'boss' | 'lab' | 'bar', color: string, carpet: string, gaps: { top?: Gap[]; bottom?: Gap[]; left?: Gap[]; right?: Gap[] }) => {
      const r = rb(ROOMS[key]);
      const g = new THREE.Group();
      scene.add(g);
      const pad = new THREE.Mesh(new THREE.BoxGeometry(r.x1 - r.x0, 0.08, r.z1 - r.z0), mat(carpet, 0.95));
      pad.position.set((r.x0 + r.x1) / 2, 0.04, (r.z0 + r.z1) / 2);
      pad.receiveShadow = true;
      g.add(pad);
      wallLine(g, r.x0, r.z0, r.x1, r.z0, gaps.top ?? [], color);
      wallLine(g, r.x0, r.z1, r.x1, r.z1, gaps.bottom ?? [], color);
      wallLine(g, r.x0, r.z0, r.x0, r.z1, gaps.left ?? [], color);
      wallLine(g, r.x1, r.z0, r.x1, r.z1, gaps.right ?? [], color);
      addRoomLight((r.x0 + r.x1) / 2, (r.z0 + r.z1) / 2 + 1, key === 'bar' ? '#ffb066' : '#ffe9c7');
      return { r, g };
    };
    const doorW = 3.4;

    const buildAll = () => {
      /* ---------------- hallways (runners, guide lights, plants, logo) ---------------- */
      const hall = new THREE.Group();
      scene.add(hall);
      const cxL = wx(29.5);
      const cxR = wx(70.5);
      const zTop = wz(3);
      const zBot = wz(97);
      const zMid = (zTop + zBot) / 2;
      [cxL, cxR].forEach((cx) => {
        makeRunner(hall, cx, zMid, 4.2, zBot - zTop, '#283246');
        makeGuide(hall, cx - 2.0, zMid, 0.1, zBot - zTop, '#38bdf8');
        makeGuide(hall, cx + 2.0, zMid, 0.1, zBot - zTop, '#38bdf8');
      });
      [wz(31), wz(67)].forEach((z) => {
        makeRunner(hall, 0, z, cxR - cxL, 3.0, '#283246');
        makeGuide(hall, 0, z - 1.4, cxR - cxL, 0.1, '#38bdf8');
        makeGuide(hall, 0, z + 1.4, cxR - cxL, 0.1, '#38bdf8');
      });
      const logo = canvasTex(1024, 256, (c) => {
        c.clearRect(0, 0, 1024, 256);
        c.fillStyle = 'rgba(251,191,36,0.9)';
        c.font = 'bold 150px sans-serif';
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        c.fillText(`${BOSS.name} HQ`, 512, 130);
      });
      const logoMesh = new THREE.Mesh(new THREE.PlaneGeometry(10, 2.5), new THREE.MeshBasicMaterial({ map: logo.t, transparent: true, toneMapped: false, depthWrite: false }));
      logoMesh.rotation.x = -Math.PI / 2;
      logoMesh.position.set(0, 0.06, wz(31));
      hall.add(logoMesh);
      [-22, -6.4, 7.2, 22.6].forEach((z) => {
        makePlant(hall, cxL - 2.4, z, 0.9);
        makePlant(hall, cxR + 2.4, z, 0.9);
      });

      /* ---------------- left lounge (between Aria and Nova) ---------------- */
      const lxc = wx(14.5);
      makeRug(hall, lxc, 0, 11.5, 6.8, '#2e3a55');
      makeSofa(hall, lxc - 4.6, 0, Math.PI / 2, '#3b4f7a', 4.4);
      makeSofa(hall, lxc + 4.6, 0, -Math.PI / 2, '#3b4f7a', 4.4);
      makeCoffeeTable(hall, lxc, 0, 2.8, 1.4, Math.PI / 2);
      makePlant(hall, lxc - 7.8, -3.4, 1.3);
      makePlant(hall, lxc - 7.8, 3.4, 1.3);
      makeFloorLamp(hall, lxc + 7.6, -3.6);
      makeFloorLamp(hall, lxc + 7.6, 3.6);
      addRoomLight(lxc, 0, '#ffe9c7');

      /* ---------------- right print & huddle area (between Blaze and Cipher) ---------------- */
      const rxc = wx(85.5);
      makeRug(hall, rxc, 0.2, 10, 6.8, '#243a3a');
      cyl(hall, 1.6, 1.6, 0.12, mat('#e7d3b0', 0.4), rxc, 1.05, 0.4);
      cyl(hall, 0.25, 0.5, 1.0, mat('#222833', 0.4, 0.6), rxc, 0.52, 0.4);
      [0, 1, 2, 3].forEach((i) => {
        const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
        const cx = rxc + Math.cos(a) * 2.7;
        const cz = 0.4 + Math.sin(a) * 2.7;
        makeChair(hall, cx, cz, '#1a2030', Math.atan2(-(rxc - cx), -(0.4 - cz)));
      });
      makePrinter(hall, rxc - 5.4, -3.7, 0);
      makePrinter(hall, rxc - 2.8, -3.7, 0);
      makeCooler(hall, rxc + 7.8, -3.8);
      makeCooler(hall, rxc + 7.8, 3.8);
      makePlant(hall, rxc + 7.6, 0, 1.2);
      makePlant(hall, rxc - 7.8, 3.6, 1.2);
      addRoomLight(rxc, 0, '#ffe9c7');

      /* ---------------- private offices ---------------- */
      const TITLES: Record<AgentId, string> = { aria: 'CONTENT PLAN', blaze: 'POST SCHEDULE', nova: 'INVITE RADAR', cipher: 'ANALYTICS' };
      AGENTS.forEach((a) => {
        const leftSide = a.id === 'aria' || a.id === 'nova';
        const rr = rb(ROOMS[a.id]);
        const doorCenter = (rr.z0 + rr.z1) / 2;
        const gaps = leftSide ? { right: [{ at: doorCenter - rr.z0, w: doorW }] } : { left: [{ at: doorCenter - rr.z0, w: doorW }] };
        const { r, g } = addRoom(a.id, a.color, leftSide ? '#27324a' : '#2a3347', gaps);
        const d = officeDesk(a.id);
        const ix = (o: number) => (leftSide ? r.x0 + o : r.x1 - o); // distance in from the outer wall
        const ox = (o: number) => (leftSide ? r.x1 - o : r.x0 + o); // distance in from the door-side wall
        const faceIn = leftSide ? Math.PI / 2 : -Math.PI / 2;
        const hue = (a.id.charCodeAt(0) * 37) % 360;

        // work zone
        makeRug(g, d.cx, d.deskZ + 1.5, 9.5, 6.4, new THREE.Color(a.color).multiplyScalar(0.22).getStyle());
        const sc: Screen[] = [];
        makeDesk(g, d.cx, d.deskZ, a.color, false, sc);
        screens[a.id] = sc;
        makeChair(g, d.cx, d.seatZ, '#1a2030');

        // back wall: credenza, art, shelves
        box(g, 6.6, 1.1, 1.0, mat('#3b2a1e', 0.55), d.cx, 0.55, r.z0 + 0.9);
        box(g, 6.8, 0.08, 1.1, mat('#6b4d38', 0.4), d.cx, 1.14, r.z0 + 0.9);
        makeDeskPlant(g, d.cx - 2.5, 1.18, r.z0 + 0.9);
        box(g, 0.6, 0.18, 0.4, mat(a.color, 0.6), d.cx + 1.8, 1.27, r.z0 + 0.9, false);
        box(g, 0.5, 0.16, 0.36, mat('#e5e7eb', 0.6), d.cx + 1.85, 1.44, r.z0 + 0.9, false);
        makeArt(g, d.cx, 2.45, r.z0 + 0.2, 3.4, 1.2, hue);
        makeShelf(g, r.x0 + 2.2, r.z0 + 0.6);
        makeShelf(g, r.x1 - 2.2, r.z0 + 0.6);

        // outer wall: themed board + cabinets
        makeBoard(g, ix(0.2), 2.0, d.deskZ + 1.2, 5.2, 2.2, faceIn, TITLES[a.id], a.color, a.id === 'cipher');
        makeCabinet(g, ix(1.0), d.deskZ + 5.4, faceIn);
        makeCabinet(g, ix(1.0), d.deskZ + 6.9, faceIn);

        // lounge corner
        makeRug(g, d.cx, r.z1 - 3.2, 10.5, 4.8, '#243049');
        makeSofa(g, d.cx, r.z1 - 1.1, Math.PI, '#33425e', 4.6);
        makeCoffeeTable(g, d.cx, r.z1 - 3.7);
        makeSofa(g, d.cx - 3.7, r.z1 - 3.7, Math.PI / 2, '#3d4d6b', 1.9);
        makeSofa(g, d.cx + 3.7, r.z1 - 3.7, -Math.PI / 2, '#3d4d6b', 1.9);
        makeFloorLamp(g, ix(1.4), r.z1 - 3.4);

        // plants
        makePlant(g, ix(1.0), r.z0 + 1.9, 1.1);
        makePlant(g, ix(1.0), r.z1 - 1.0, 1.2);
        makePlant(g, ox(1.0), r.z0 + 1.6, 1.0);
        makePlant(g, ox(1.0), r.z1 - 1.0, 1.2);

        if (a.id === 'cipher') {
          makeRack(g, ix(4.9), r.z0 + 1.2, 0);
          makeRack(g, ox(4.9), r.z0 + 1.2, 0);
        }
        doorLight(g, leftSide ? r.x1 : r.x0, doorCenter, false, doorW, a.color);
      });

      /* ---------------- boss office ---------------- */
      const bo = rb(ROOMS.boss);
      const bossGroup = addRoom('boss', BOSS.color, '#3a2c1f', { bottom: [{ at: (bo.x1 - bo.x0) / 2, w: doorW }] });
      const bg = bossGroup.g;
      const bd = officeDesk('boss');
      makeRug(bg, 0, bd.deskZ + 1.7, 11, 6, '#4a2f1b');
      const bsc: Screen[] = [];
      makeDesk(bg, 0, bd.deskZ, BOSS.color, true, bsc);
      screens.boss = bsc;
      makeChair(bg, 0, bd.seatZ, '#2a1a10');
      [bo.x0 + 2.2, bo.x0 + 5.6, bo.x1 - 5.6, bo.x1 - 2.2].forEach((x) => makeShelf(bg, x, bo.z0 + 0.6, 0, 3.2));
      box(bg, 7.4, 1.1, 1.0, mat('#3b2a1e', 0.55), 0, 0.55, bo.z0 + 0.9);
      box(bg, 7.6, 0.08, 1.1, mat('#7a5a3a', 0.35), 0, 1.14, bo.z0 + 0.9);
      makeNeon(bg, 0, 2.45, bo.z0 + 0.25, 6.4, 1.3, `👑 ${BOSS.name}`, '#f59e0b', '#fde68a');
      // trophies on the credenza
      cyl(bg, 0.18, 0.3, 0.12, mat('#fbbf24', 0.25, 0.9), 2.9, 1.25, bo.z0 + 0.9);
      cyl(bg, 0.28, 0.08, 0.35, mat('#fbbf24', 0.25, 0.9), 2.9, 1.5, bo.z0 + 0.9);
      cyl(bg, 0.18, 0.3, 0.12, mat('#fbbf24', 0.25, 0.9), -2.9, 1.25, bo.z0 + 0.9);
      cyl(bg, 0.28, 0.08, 0.35, mat('#fbbf24', 0.25, 0.9), -2.9, 1.5, bo.z0 + 0.9);
      // lounge (left) + globe (right)
      makeRug(bg, bo.x0 + 3.8, bo.z1 - 3.2, 8, 4.4, '#4a2f1b');
      makeSofa(bg, bo.x0 + 3.4, bo.z1 - 1.1, Math.PI, '#6b4a2a', 4.4);
      makeCoffeeTable(bg, bo.x0 + 3.4, bo.z1 - 3.5, 2.4, 1.2);
      makeFloorLamp(bg, bo.x0 + 1.0, bo.z0 + 2.4);
      cyl(bg, 0.5, 0.6, 0.15, mat('#fbbf24', 0.3, 0.8), bo.x1 - 3.2, 0.08, bo.z1 - 2.2);
      cyl(bg, 0.06, 0.06, 1.4, mat('#fbbf24', 0.3, 0.8), bo.x1 - 3.2, 0.8, bo.z1 - 2.2, 8);
      sphere(bg, 0.8, new THREE.MeshStandardMaterial({ color: '#2563eb', roughness: 0.4, metalness: 0.2 }), bo.x1 - 3.2, 2.0, bo.z1 - 2.2);
      makePlant(bg, bo.x1 - 1.0, bo.z1 - 1.0, 1.4);
      makePlant(bg, bo.x1 - 1.0, bo.z0 + 1.8, 1.2);
      makePlant(bg, bo.x0 + 1.0, bo.z1 - 1.0, 1.2);
      doorLight(bg, 0, bo.z1, true, doorW, BOSS.color);

      /* ---------------- idea lab ---------------- */
      const lb = rb(ROOMS.lab);
      const labCenterZ = (lb.z0 + lb.z1) / 2;
      const lab = addRoom('lab', '#a78bfa', '#2d2744', { left: [{ at: labCenterZ - lb.z0, w: doorW }], right: [{ at: labCenterZ - lb.z0, w: doorW }] });
      makeRug(lab.g, 0, TABLE_C.z, 15, 9, '#3a2f5c');
      const tableTop = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 0.16, 40), mat('#3d2f4f', 0.35, 0.2));
      tableTop.scale.set(4.2, 1, 2.1);
      tableTop.position.set(0, 1.1, TABLE_C.z);
      tableTop.castShadow = true;
      tableTop.receiveShadow = true;
      lab.g.add(tableTop);
      cyl(lab.g, 0.6, 0.9, 1.05, mat('#201832', 0.4, 0.4), 0, 0.55, TABLE_C.z);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(1, 0.02, 8, 60), glowMat('#a78bfa', 1.8));
      ring.rotation.x = Math.PI / 2;
      ring.scale.set(4.2, 2.1, 1);
      ring.position.set(0, 1.19, TABLE_C.z);
      lab.g.add(ring);
      const holo = sphere(lab.g, 0.3, new THREE.MeshStandardMaterial({ color: '#c4b5fd', emissive: '#a78bfa', emissiveIntensity: 1.6, transparent: true, opacity: 0.8 }), 0, 1.8, TABLE_C.z);
      holo.userData.holo = true;
      (IDS as MemberId[]).forEach((id) => {
        const [sx, sz] = LAB_SEATS[id];
        const dir = new THREE.Vector3(TABLE_C.x - sx, 0, TABLE_C.z - sz);
        makeChair(lab.g, sx, sz, '#2b2142', Math.atan2(-dir.x, -dir.z));
      });
      const wb = canvasTex(512, 256, (c) => {
        c.fillStyle = '#f8fafc';
        c.fillRect(0, 0, 512, 256);
        c.fillStyle = '#6d28d9';
        c.font = 'bold 34px sans-serif';
        c.fillText('IDEA LAB', 20, 52);
        c.strokeStyle = '#94a3b8';
        c.lineWidth = 3;
        [[30, 90, 200], [30, 130, 300], [30, 170, 160]].forEach(([x, y, w]) => { c.beginPath(); c.moveTo(x, y); c.lineTo(x + w, y); c.stroke(); });
        ['#fde68a', '#fbcfe8', '#bae6fd', '#bbf7d0'].forEach((col, i) => { c.fillStyle = col; c.fillRect(300 + (i % 2) * 90, 80 + Math.floor(i / 2) * 80, 74, 66); });
      });
      const board = new THREE.Mesh(new THREE.PlaneGeometry(7.6, 2.3), new THREE.MeshBasicMaterial({ map: wb.t, toneMapped: false }));
      board.position.set(0, 1.95, lb.z0 + 0.25);
      lab.g.add(board);
      box(lab.g, 7.8, 2.5, 0.08, mat('#cbd5e1', 0.3, 0.6), 0, 1.95, lb.z0 + 0.2, false);
      makeSofa(lab.g, -6.2, lb.z1 - 1.1, Math.PI, '#3b2f5c', 4.6);
      makeSofa(lab.g, 6.2, lb.z1 - 1.1, Math.PI, '#3b2f5c', 4.6);
      makeFloorLamp(lab.g, lb.x0 + 1.2, lb.z0 + 1.6, '#c4b5fd');
      makeFloorLamp(lab.g, lb.x1 - 1.2, lb.z0 + 1.6, '#c4b5fd');
      makePlant(lab.g, lb.x0 + 1.0, lb.z1 - 1.0, 1.2);
      makePlant(lab.g, lb.x1 - 1.0, lb.z1 - 1.0, 1.2);
      doorLight(lab.g, lb.x0, labCenterZ, false, doorW, '#a78bfa');
      doorLight(lab.g, lb.x1, labCenterZ, false, doorW, '#a78bfa');

      /* ---------------- mini bar ---------------- */
      const mb = rb(ROOMS.bar);
      const barDoorZ = wz(84);
      const bar = addRoom('bar', '#fb923c', '#3b2a22', { left: [{ at: barDoorZ - mb.z0, w: doorW }], right: [{ at: barDoorZ - mb.z0, w: doorW }] });
      const counterZ = BAR_COUNTER_Z;
      box(bar.g, 17.6, 1.3, 1.4, mat('#6b3f22', 0.5), 0, 0.65, counterZ);
      box(bar.g, 18, 0.14, 1.7, mat('#e7d3b0', 0.3, 0.1), 0, 1.37, counterZ);
      box(bar.g, 17.6, 0.04, 0.04, glowMat('#fb923c', 1.8), 0, 0.12, counterZ + 0.72, false);
      // back counter, shelf, fridges
      box(bar.g, 17.6, 1.2, 0.9, mat('#4a2b18', 0.6), 0, 0.6, mb.z0 + 0.8);
      box(bar.g, 15, 0.08, 0.5, mat('#e7d3b0'), 0, 1.9, mb.z0 + 0.4);
      for (let i = 0; i < 12; i++) cyl(bar.g, 0.14, 0.12, 0.26, mat(new THREE.Color().setHSL(i / 12, 0.5, 0.7), 0.4), -6.6 + i * 1.2, 2.08, mb.z0 + 0.4);
      box(bar.g, 1.6, 3.2, 1.2, mat('#c8d0dc', 0.3, 0.7), mb.x1 - 1.3, 1.6, mb.z0 + 1.1);
      box(bar.g, 1.6, 3.2, 1.2, mat('#c8d0dc', 0.3, 0.7), mb.x0 + 1.3, 1.6, mb.z0 + 1.1);
      // coffee machine
      const cm = new THREE.Group();
      cm.position.set(-1.2, 1.44, counterZ);
      box(cm, 1.3, 1.1, 0.8, mat('#1a1d26', 0.3, 0.6), 0, 0.55, 0);
      box(cm, 0.5, 0.25, 0.04, glowMat('#34d399', 1.6), 0.25, 0.8, 0.42, false);
      box(cm, 0.14, 0.14, 0.04, glowMat('#ef4444', 1.8), -0.3, 0.8, 0.42, false);
      cyl(cm, 0.09, 0.09, 0.3, mat('#9ca3af', 0.3, 0.8), 0, 0.35, 0.3);
      bar.g.add(cm);
      [-7.4, -6.6, -3.4, -2.6, 0.2, 0.9, 2.8, 4.0, 4.8, 6.4, 7.6].forEach((x, i) => {
        cyl(bar.g, 0.17, 0.13, 0.3, mat(i % 2 ? '#ffffff' : '#fb923c', 0.4), x, 1.6, counterZ + (i % 2 ? 0.25 : -0.15));
      });
      [3.4, 3.8].forEach((x) => { const tr = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.09, 10, 18), mat('#e0a458', 0.6)); tr.rotation.x = Math.PI / 2; tr.position.set(x, 1.5, counterZ); bar.g.add(tr); });
      cyl(bar.g, 0.3, 0.38, 0.5, mat('#9ca3af', 0.25, 0.9), 5.4, 1.7, counterZ);
      makeNeon(bar.g, 0, 2.75, mb.z0 + 0.2, 5.4, 1.0, '☕ MINI BAR', '#fb923c', '#fed7aa');
      // bistro tables + stools
      [-9.6, 9.6].forEach((x) => {
        const tz = mb.z1 - 3.2;
        cyl(bar.g, 0.8, 0.8, 0.1, mat('#e7d3b0'), x, 1.7, tz);
        cyl(bar.g, 0.1, 0.1, 1.6, mat('#222'), x, 0.85, tz);
        [-1.3, 1.3].forEach((dx) => {
          cyl(bar.g, 0.35, 0.3, 0.12, mat('#fb923c', 0.5), x + dx, 1.25, tz);
          cyl(bar.g, 0.06, 0.06, 1.2, mat('#222'), x + dx, 0.62, tz, 8);
        });
      });
      makePlant(bar.g, mb.x0 + 1.0, mb.z1 - 1.0, 1.2);
      makePlant(bar.g, mb.x1 - 1.0, mb.z1 - 1.0, 1.2);
      doorLight(bar.g, mb.x0, barDoorZ, false, doorW, '#fb923c');
      doorLight(bar.g, mb.x1, barDoorZ, false, doorW, '#fb923c');
    };
    buildAll();

    // steam above coffee machine
    const steam: THREE.Mesh[] = [];
    for (let i = 0; i < 4; i++) {
      const s = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.0, depthWrite: false }));
      s.position.set(-1.2, 3, BAR_COUNTER_Z);
      scene.add(s);
      steam.push(s);
    }

    /* ---- characters ---- */
    const bots: Record<string, Bot> = {};
    IDS.forEach((id) => {
      const b = makeBot(id);
      b.pos.copy(spotOf(id, 'office'));
      b.group.position.copy(b.pos);
      b.group.rotation.y = Math.PI;
      scene.add(b.group);
      bots[id] = b;
    });
    const botGroups = IDS.map((id) => bots[id].group);

    /* ---- sizing ---- */
    let inited = false;
    const resize = () => {
      const w = host.clientWidth || 600;
      const h = host.clientHeight || 380;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      const narrow = camera.aspect < 1.45 ? 1.45 / camera.aspect : 1;
      const dist = 84 * Math.min(1.9, narrow);
      const dir = new THREE.Vector3(0, 0.78, 0.9).normalize();
      if (!inited) {
        camera.position.copy(controls.target).addScaledVector(dir, dist);
        inited = true;
      }
      camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(host);

    /* ---- picking ---- */
    const ray = new THREE.Raycaster();
    const ndc = new THREE.Vector2();
    const pick = (e: PointerEvent): MemberId | null => {
      const rect = renderer.domElement.getBoundingClientRect();
      ndc.set(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
      ray.setFromCamera(ndc, camera);
      const hit = ray.intersectObjects(botGroups, true)[0];
      if (!hit) return null;
      let o: THREE.Object3D | null = hit.object;
      while (o && o.userData.id === undefined) o = o.parent;
      return (o?.userData.id as MemberId) ?? null;
    };
    let downX = 0;
    let downY = 0;
    const onDown = (e: PointerEvent) => { downX = e.clientX; downY = e.clientY; };
    const onUp = (e: PointerEvent) => {
      if (Math.hypot(e.clientX - downX, e.clientY - downY) > 5) return;
      const id = pick(e);
      if (!id) return;
      if (id === 'boss') live.current.onBossClick();
      else live.current.onSelect(id);
    };
    const onMove = (e: PointerEvent) => {
      renderer.domElement.style.cursor = pick(e) ? 'pointer' : 'grab';
    };
    renderer.domElement.addEventListener('pointerdown', onDown);
    renderer.domElement.addEventListener('pointerup', onUp);
    renderer.domElement.addEventListener('pointermove', onMove);

    /* ---- loop ---- */
    let raf = 0;
    let visible = true;
    const io = new IntersectionObserver(([e]) => { visible = e.isIntersecting; });
    io.observe(host);
    let last = performance.now();
    let night = live.current.isNight ? 1 : 0;
    let screenClock = 0;
    const tmp = new THREE.Vector3();

    const wrap = (a: number) => { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; };

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      if (!visible || document.hidden) { last = now; return; }
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      const t = now / 1000;
      const L = live.current;
      night += ((L.isNight ? 1 : 0) - night) * Math.min(1, dt * 1.2);

      hemi.intensity = lerp(0.95, 0.32, night);
      sun.intensity = lerp(1.5, 0.25, night);
      sun.color.set(night > 0.5 ? '#8fa8ff' : '#fff1d6');
      roomLights.forEach((l) => { l.intensity = lerp(9, 60, night); });
      skyMat.color.setScalar(lerp(1, 0.32, night));
      scene.background = new THREE.Color().setRGB(lerp(0.07, 0.02, night), lerp(0.09, 0.03, night), lerp(0.14, 0.06, night));

      // bots
      IDS.forEach((id) => {
        const b = bots[id];
        const target = L.places[id];
        if (b.place !== target) {
          const prev = b.place;
          const midWalk = b.path.length > 0;
          b.place = target;
          b.path = routeTo(id, b.pos, prev, target, midWalk);
        }
        b.walking = b.path.length > 0;
        if (b.walking) {
          const next = b.path[0];
          tmp.subVectors(next, b.pos);
          tmp.y = 0;
          const dist = tmp.length();
          const step = 11 * dt;
          if (dist <= step) { b.pos.copy(next); b.path.shift(); }
          else { tmp.normalize(); b.pos.addScaledVector(tmp, step); b.yaw = Math.atan2(tmp.x, tmp.z); }
        }
        let faceYaw = b.yaw;
        if (!b.walking) {
          if (b.place === 'lab') faceYaw = Math.atan2(TABLE_C.x - b.pos.x, TABLE_C.z - b.pos.z);
          else faceYaw = Math.PI;
        }
        const cur = b.group.rotation.y;
        b.group.rotation.y = cur + wrap(faceYaw - cur) * Math.min(1, dt * 9);
        const seated = !b.walking && (b.place === 'office' || b.place === 'lab');
        b.group.position.set(b.pos.x, b.walking ? Math.abs(Math.sin(t * 14)) * 0.12 : 0, b.pos.z);
        const swing = Math.sin(t * 14) * 0.7;
        const activeStatus = id === 'boss' ? true : L.activity[id as AgentId].status !== 'idle' && L.activity[id as AgentId].status !== 'paused';
        b.legL.rotation.x = b.walking ? swing : seated ? -1.5 : 0;
        b.legR.rotation.x = b.walking ? -swing : seated ? -1.5 : 0;
        if (b.walking) {
          b.armL.rotation.x = -swing * 0.8;
          b.armR.rotation.x = swing * 0.8;
        } else if (b.place === 'office') {
          const k = activeStatus ? 1 : 0.15;
          b.armL.rotation.x = -1.15 + Math.sin(t * 19) * 0.12 * k;
          b.armR.rotation.x = -1.15 + Math.cos(t * 17) * 0.12 * k;
        } else if (b.place === 'bar') {
          b.armL.rotation.x = 0.05;
          b.armR.rotation.x = -1.3 + Math.sin(t * 2) * 0.1;
        } else {
          b.armL.rotation.x = -0.6;
          b.armR.rotation.x = -0.6 + Math.sin(t * 2.5 + id.length) * 0.35;
        }
        b.cup.visible = b.place === 'bar' && !b.walking;
        const bi = IDS.indexOf(id);
        const blinkPhase = (t + bi * 1.7) % 4.2;
        b.eyes.forEach((e) => { e.scale.y = blinkPhase > 4.08 ? 0.1 : 1; });
        b.spin.forEach((s, k) => { s.rotation.y = t * (1.6 + k * 0.5); });
        if (b.orb) (b.orb.material as THREE.MeshStandardMaterial).emissiveIntensity = 1.9 + Math.sin(t * 3 + bi) * 0.8;
        // tags
        const tag = tagRefs.current[id];
        if (tag) {
          tmp.set(b.pos.x, 4.7, b.pos.z).project(camera);
          const rect = renderer.domElement.getBoundingClientRect();
          const sx = (tmp.x * 0.5 + 0.5) * rect.width;
          const sy = (-tmp.y * 0.5 + 0.5) * rect.height;
          tag.style.transform = `translate(${sx}px, ${sy}px) translate(-50%, -100%)`;
          tag.style.opacity = tmp.z < 1 ? '1' : '0';
        }
      });

      // room labels
      ROOM_LABELS.forEach((rl) => {
        const el = roomRefs.current[rl.key];
        if (!el) return;
        tmp.set(rl.x, 3.5, rl.z).project(camera);
        const rect = renderer.domElement.getBoundingClientRect();
        el.style.transform = `translate(${(tmp.x * 0.5 + 0.5) * rect.width}px, ${(-tmp.y * 0.5 + 0.5) * rect.height}px) translate(-50%, -50%)`;
      });

      // monitors (~12 fps)
      screenClock += dt;
      if (screenClock > 0.08) {
        screenClock = 0;
        IDS.forEach((id) => {
          const away = bots[id].place !== 'office';
          const act = id === 'boss' ? !away : !away && L.activity[id as AgentId].status !== 'idle' && L.activity[id as AgentId].status !== 'paused';
          screens[id]?.forEach((s, si) => {
            const c = s.c;
            c.fillStyle = away ? '#05070b' : '#07101c';
            c.fillRect(0, 0, 192, 108);
            if (away) { s.t.needsUpdate = true; return; }
            const speed = act ? 26 : 6;
            for (let r = 0; r < 12; r++) {
              const y = ((r * 10 + t * speed + si * 17) % 120) - 8;
              const len = 30 + ((r * 53 + si * 11) % 90);
              const ind = ((r * 7) % 3) * 12;
              c.fillStyle = r % 3 === 0 ? s.color : r % 3 === 1 ? '#e2e8f0' : '#a78bfa';
              c.globalAlpha = act ? 0.9 : 0.4;
              c.fillRect(10 + ind, y, len, 4);
            }
            c.globalAlpha = 1;
            c.fillStyle = s.color;
            for (let b2 = 0; b2 < 6; b2++) {
              const h = 6 + (Math.sin(t * (act ? 3 : 1) + b2 * 1.3) * 0.5 + 0.5) * 22;
              c.fillRect(130 + b2 * 9, 100 - h, 6, h);
            }
            s.t.needsUpdate = true;
          });
        });
      }

      // steam + hologram
      steam.forEach((s, i) => {
        const f = (t * 0.45 + i / steam.length) % 1;
        s.position.y = 3.0 + f * 1.6;
        s.position.x = -1.2 + Math.sin(t * 2 + i) * 0.15;
        s.scale.setScalar(0.6 + f);
        (s.material as THREE.MeshBasicMaterial).opacity = L.phase === 'coffee' ? 0.35 * (1 - f) : 0;
      });
      scene.traverse((o) => {
        if (o.userData.holo) {
          o.position.y = 1.8 + Math.sin(t * 2) * 0.12;
          o.rotation.y = t;
          (o as THREE.Mesh).scale.setScalar(L.phase === 'meeting' ? 1.5 + Math.sin(t * 4) * 0.15 : 0.9);
        }
      });

      controls.update();
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      io.disconnect();
      ro.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onDown);
      renderer.domElement.removeEventListener('pointerup', onUp);
      renderer.domElement.removeEventListener('pointermove', onMove);
      controls.dispose();
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
        const mt = m.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mt)) mt.forEach((x) => x.dispose());
        else mt?.dispose();
      });
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return (
    <div ref={hostRef} className="absolute inset-0 overflow-hidden" style={{ background: '#0b0e14' }}>
      {/* room labels */}
      {ROOM_LABELS.map((rl) => (
        <div
          key={rl.key}
          ref={(el) => { roomRefs.current[rl.key] = el; }}
          className="pointer-events-none absolute left-0 top-0 z-10 flex flex-col items-center"
          style={{ willChange: 'transform' }}
        >
          <span
            className="whitespace-nowrap rounded-full border px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider backdrop-blur sm:text-[10px]"
            style={{ borderColor: `${rl.color}88`, background: 'rgba(10,14,22,0.72)', color: rl.color, boxShadow: `0 0 12px ${rl.color}55` }}
          >
            {rl.text}
          </span>
          <span className="mt-0.5 hidden whitespace-nowrap text-[9px] text-slate-400 sm:block">{rl.sub}</span>
        </div>
      ))}
      {/* member tags + bubbles */}
      {IDS.map((id) => {
        const place = places[id];
        const act = id === 'boss' ? null : activity[id as AgentId];
        const bubble = speech[id] ?? (place === 'office' && act ? act.bubble : undefined);
        const busy = id === 'boss' ? phase !== 'work' : !!act && act.status !== 'idle' && act.status !== 'paused';
        return (
          <div
            key={id}
            ref={(el) => { tagRefs.current[id] = el; }}
            className="pointer-events-none absolute left-0 top-0 z-20 flex flex-col items-center gap-1"
            style={{ willChange: 'transform', zIndex: speech[id] ? 40 : 20 }}
          >
            {bubble && (
              <div
                className="w-max max-w-[130px] rounded-lg border bg-[#141821]/95 px-2 py-1 text-[8px] leading-snug text-slate-100 shadow-xl backdrop-blur sm:max-w-[210px] sm:px-2.5 sm:py-1.5 sm:text-[11px]"
                style={{ borderColor: `${COLORS[id]}88` }}
              >
                <span className="line-clamp-3">{bubble}</span>
              </div>
            )}
            <div
              className="flex items-center gap-1 rounded-full border bg-[#141821]/95 px-1.5 py-px text-[8px] font-semibold text-white sm:px-2 sm:py-0.5 sm:text-[10px]"
              style={{ borderColor: `${COLORS[id]}88` }}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${busy ? 'animate-pulse bg-emerald-400' : 'bg-slate-500'}`} />
              {id === 'boss' ? '👑 ' : ''}{NAMES[id]}
            </div>
          </div>
        );
      })}
      <div className="pointer-events-none absolute bottom-2 right-3 z-10 rounded-full bg-black/45 px-2.5 py-1 text-[9px] text-slate-300 backdrop-blur sm:text-[10px]">
        Drag para umikot · scroll para mag-zoom · click ang bot
      </div>
    </div>
  );
}
