/*
  # Server-side 24/7 worker schema

  New tables: bot_settings (single row), scheduled_posts, invite_queue, ab_results.
  scheduled_posts replaces the browser-timer `posts` table (existing rows are copied over).
  Realtime is enabled so the Virtual Office updates live from bot_logs.
  pg_cron + pg_net call the `auto-bot-worker` Edge Function every minute.
  API keys are NOT stored here: set them as Edge Function secrets.
*/

CREATE TABLE IF NOT EXISTS bot_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  auto_pilot_enabled boolean NOT NULL DEFAULT false,
  max_posts_per_hour integer NOT NULL DEFAULT 6,
  max_invites_per_hour integer NOT NULL DEFAULT 20,
  min_queue_size integer NOT NULL DEFAULT 3,
  winner_min_clicks integer NOT NULL DEFAULT 50,
  est_audience integer NOT NULL DEFAULT 500,  -- estimated reach per post, used as the CTR denominator
  platform_discord boolean NOT NULL DEFAULT true,
  platform_telegram boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO bot_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS scheduled_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid REFERENCES games(id) ON DELETE CASCADE,
  game_title text NOT NULL DEFAULT '',
  platforms text[] NOT NULL DEFAULT '{}',
  content text NOT NULL DEFAULT '',
  hashtags text NOT NULL DEFAULT '',
  tone text NOT NULL DEFAULT 'hype',
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','published','failed')),
  scheduled_at timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz,
  variant_group uuid,
  variant text CHECK (variant IN ('a','b')),
  impressions integer NOT NULL DEFAULT 0,
  clicks integer NOT NULL DEFAULT 0,
  error text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS scheduled_posts_due_idx ON scheduled_posts (status, scheduled_at);
CREATE INDEX IF NOT EXISTS scheduled_posts_group_idx ON scheduled_posts (variant_group);

CREATE TABLE IF NOT EXISTS invite_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid REFERENCES games(id) ON DELETE SET NULL,
  platform text NOT NULL DEFAULT 'discord',
  target_user text NOT NULL,
  message text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','failed')),
  error text,
  sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS invite_queue_status_idx ON invite_queue (status, created_at);

CREATE TABLE IF NOT EXISTS ab_results (
  variant_group uuid PRIMARY KEY,
  game_id uuid REFERENCES games(id) ON DELETE CASCADE,
  winner text NOT NULL CHECK (winner IN ('a','b')),
  ctr_a numeric NOT NULL DEFAULT 0,
  ctr_b numeric NOT NULL DEFAULT 0,
  decided_at timestamptz NOT NULL DEFAULT now()
);

-- copy anything created by the old browser-timer table
INSERT INTO scheduled_posts (id, game_id, game_title, platforms, content, hashtags, tone, status, scheduled_at, published_at, created_at)
SELECT id, game_id, game_title, platforms, content, hashtags, tone,
       CASE status WHEN 'published' THEN 'published' WHEN 'failed' THEN 'failed' ELSE 'queued' END,
       scheduled_at, published_at, created_at
FROM posts WHERE status <> 'draft'
ON CONFLICT (id) DO NOTHING;

-- atomic click counter used by the track-click function
CREATE OR REPLACE FUNCTION increment_click(p_group uuid, p_variant text) RETURNS text
LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  UPDATE scheduled_posts SET clicks = clicks + 1
  WHERE id = (SELECT id FROM scheduled_posts WHERE variant_group = p_group AND variant = p_variant ORDER BY created_at DESC LIMIT 1)
  RETURNING game_id::text;
$$;

ALTER TABLE bot_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE invite_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE ab_results ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON bot_settings, scheduled_posts, invite_queue TO anon, authenticated;
GRANT SELECT ON ab_results TO anon, authenticated;

DROP POLICY IF EXISTS "anon_all_bot_settings" ON bot_settings;
CREATE POLICY "anon_all_bot_settings" ON bot_settings FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_all_scheduled_posts" ON scheduled_posts;
CREATE POLICY "anon_all_scheduled_posts" ON scheduled_posts FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_all_invite_queue" ON invite_queue;
CREATE POLICY "anon_all_invite_queue" ON invite_queue FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_read_ab_results" ON ab_results;
CREATE POLICY "anon_read_ab_results" ON ab_results FOR SELECT TO anon, authenticated USING (true);

-- Realtime for the Virtual Office
DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE bot_logs;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE bot_settings;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 24/7 trigger: every minute, independent of any browser.
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;
/*
  ONE-TIME SETUP (run in the SQL editor, with your own values):
    select vault.create_secret('https://YOUR-PROJECT.supabase.co', 'project_url');
    select vault.create_secret('YOUR_SERVICE_ROLE_KEY', 'service_role_key');
*/
SELECT cron.unschedule('auto-bot-worker') WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'auto-bot-worker');
SELECT cron.schedule(
  'auto-bot-worker',
  '* * * * *',
  $$
  SELECT net.http_post(
    url := (SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name = 'project_url') || '/functions/v1/auto-bot-worker',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || (SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name = 'service_role_key')
    ),
    body := '{}'::jsonb,
    timeout_milliseconds := 50000
  );
  $$
);
