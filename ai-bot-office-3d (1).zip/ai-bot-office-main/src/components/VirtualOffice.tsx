import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Clock, Coffee, Lightbulb, Moon, Pause, Play, Sun, X } from 'lucide-react';
import type { AgentId } from '@/lib/agents';
import { AGENTS } from '@/lib/agents';
import type { AgentActivity } from '@/lib/useAgentActivity';
import Office3D from './Office3D';
import { BOSS, useOfficeSim, type Idea, type Phase } from '@/lib/office';

const CW = 1100;
const CH = 740;

function statusMeta(status: string): { label: string; dot: string; text: string } {
  switch (status) {
    case 'posting':
      return { label: 'Posting', dot: 'bg-emerald-400', text: 'text-emerald-300' };
    case 'typing':
      return { label: 'Typing', dot: 'bg-sky-400', text: 'text-sky-300' };
    case 'thinking':
      return { label: 'Thinking', dot: 'bg-amber-400', text: 'text-amber-300' };
    case 'paused':
      return { label: 'Paused', dot: 'bg-slate-500', text: 'text-slate-400' };
    default:
      return { label: 'Idle / Resting', dot: 'bg-slate-500', text: 'text-slate-400' };
  }
}

function IdeaBoard({ ideas, phase }: { ideas: Idea[]; phase: Phase }) {
  const nameOf = (id: string) => AGENTS.find((a) => a.id === id)?.name ?? id;
  const colorOf = (id: string) => AGENTS.find((a) => a.id === id)?.color ?? '#94a3b8';
  return (
    <div className="relative z-20 border-t border-white/[0.06] bg-[#0d1117]/80 px-5 py-3">
      <div className="mb-2 flex items-center justify-between">
        <h4 className="flex items-center gap-2 text-xs font-semibold text-white">
          <Lightbulb className="h-3.5 w-3.5 text-violet-300" />
          Team Idea Board
          <span className="font-normal text-slate-500">· mga idea ng bots, aprubado ni {BOSS.name}</span>
        </h4>
        <span className="text-[11px] text-slate-500">
          {phase === 'work' ? 'Everyone is working' : phase === 'meeting' ? 'Brainstorming now…' : 'Coffee break…'}
        </span>
      </div>
      {ideas.length === 0 ? (
        <p className="py-2 text-xs text-slate-500">Wala pang idea. Pindutin ang “Brainstorm” o hintayin ang next team meeting.</p>
      ) : (
        <ul className="grid gap-1.5 sm:grid-cols-2">
          {ideas.slice(0, 6).map((i) => (
            <li key={i.id} className="rounded-lg border border-white/[0.05] bg-white/[0.03] px-3 py-2 text-xs">
              <span className="font-semibold" style={{ color: colorOf(i.by) }}>{nameOf(i.by)}</span>
              <span className="text-slate-300"> — {i.text}</span>
              <p className="mt-0.5 text-[11px] text-amber-300/90">👑 {BOSS.name}: {i.verdict}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ---------- main component ---------- */

export default function VirtualOffice({
  activity,
  clock,
  isNight,
  paused,
  onPauseToggle,
}: {
  activity: Record<AgentId, AgentActivity>;
  clock: string;
  isNight: boolean;
  paused: Record<string, boolean>;
  onPauseToggle: (id: AgentId) => void;
}) {
  const [selected, setSelected] = useState<AgentId | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    if (selected && !AGENTS.find((a) => a.id === selected)) setSelected(null);
  }, [selected]);

  const openDrawer = (id: AgentId) => {
    setSelected(id);
    setDrawerOpen(true);
  };

  const sim = useOfficeSim(paused);

  return (
    <div className="relative overflow-hidden rounded-xl border border-white/[0.06] bg-gradient-to-b from-[#0e1420] to-[#0b0e14]">
      {/* ambience tint */}
      <motion.div
        className="pointer-events-none absolute inset-0 z-10"
        animate={{
          background: isNight
            ? 'linear-gradient(180deg, rgba(30,58,138,0.12), rgba(11,14,20,0.55))'
            : 'linear-gradient(180deg, rgba(251,191,36,0.07), rgba(11,14,20,0.2))',
        }}
        transition={{ duration: 3 }}
      />

      {/* header */}
      <div className="relative z-20 flex items-center justify-between border-b border-white/[0.06] px-5 py-3">
        <div className="flex items-center gap-2.5">
          <span className="rounded-lg bg-emerald-500/15 p-2 text-emerald-400">
            <Bot className="h-4 w-4" />
          </span>
          <div>
            <h3 className="text-sm font-semibold text-white">24/7 Virtual AI Office Headquarters</h3>
            <p className="text-[11px] text-slate-500">Click a bot to inspect it · {BOSS.name} the Boss leads the team</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-2 sm:gap-3">
          <button
            type="button"
            onClick={() => sim.trigger('brainstorm')}
            disabled={sim.phase !== 'work'}
            className="flex items-center gap-1.5 rounded-full border border-violet-400/30 bg-violet-500/10 px-3 py-1 text-xs font-medium text-violet-300 transition-colors hover:bg-violet-500/20 disabled:opacity-40"
          >
            <Lightbulb className="h-3.5 w-3.5" /> Brainstorm
          </button>
          <button
            type="button"
            onClick={() => sim.trigger('coffee')}
            disabled={sim.phase !== 'work'}
            className="flex items-center gap-1.5 rounded-full border border-orange-400/30 bg-orange-500/10 px-3 py-1 text-xs font-medium text-orange-300 transition-colors hover:bg-orange-500/20 disabled:opacity-40"
          >
            <Coffee className="h-3.5 w-3.5" /> Coffee Break
          </button>
          <motion.div
            key={isNight ? 'night' : 'day'}
            initial={{ opacity: 0, rotate: -30 }}
            animate={{ opacity: 1, rotate: 0 }}
            className={`flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium ${
              isNight
                ? 'border-indigo-500/30 bg-indigo-500/10 text-indigo-300'
                : 'border-amber-500/30 bg-amber-500/10 text-amber-300'
            }`}
          >
            {isNight ? <Moon className="h-3.5 w-3.5" /> : <Sun className="h-3.5 w-3.5" />}
            {isNight ? 'Night Shift' : 'Day Shift'}
          </motion.div>
          <div className="flex items-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.04] px-3 py-1 font-mono text-xs text-white">
            <Clock className="h-3.5 w-3.5 text-slate-400" />
            {clock}
          </div>
        </div>
      </div>

      {/* office floor */}
      <div className="relative min-h-[340px] w-full" style={{ aspectRatio: `${CW} / ${CH}` }}>
        <Office3D
          activity={activity}
          places={sim.places}
          speech={sim.speech}
          phase={sim.phase}
          isNight={isNight}
          onSelect={openDrawer}
          onBossClick={() => sim.trigger('brainstorm')}
        />
      </div>

      <IdeaBoard ideas={sim.ideas} phase={sim.phase} />

      {/* inspector drawer */}
      <AnimatePresence>
        {drawerOpen && selected && (
          <>
            <motion.div
              className="absolute inset-0 z-30 bg-black/50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDrawerOpen(false)}
            />
            <motion.div
              className="absolute right-0 top-0 z-40 flex h-full w-full max-w-sm flex-col border-l border-white/[0.08] bg-[#141821] shadow-2xl"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            >
              {(() => {
                const agent = AGENTS.find((a) => a.id === selected)!;
                const act = activity[selected];
                const meta = statusMeta(act.status);
                return (
                  <>
                    <div className="flex items-start justify-between border-b border-white/[0.06] px-5 py-4">
                      <div className="flex items-center gap-3">
                        <span
                          className="flex h-10 w-10 items-center justify-center rounded-xl text-lg font-bold"
                          style={{ backgroundColor: `${agent.color}22`, color: agent.color }}
                        >
                          {agent.name[0]}
                        </span>
                        <div>
                          <h4 className="font-semibold text-white">{agent.name}</h4>
                          <p className="text-xs text-slate-400">{agent.role}</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setDrawerOpen(false)}
                        className="rounded-lg p-1.5 text-slate-400 hover:bg-white/[0.06] hover:text-white"
                        aria-label="Close inspector"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="flex-1 space-y-4 overflow-y-auto p-5">
                      <div className="flex items-center gap-2 rounded-lg bg-white/[0.04] px-3 py-2.5">
                        <span className={`h-2 w-2 rounded-full ${meta.dot} ${act.status !== 'idle' ? 'animate-pulse' : ''}`} />
                        <span className={`text-sm font-medium ${meta.text}`}>{meta.label}</span>
                      </div>

                      <div>
                        <p className="mb-1.5 text-xs font-medium text-slate-400">Current Task</p>
                        <p className="rounded-lg bg-white/[0.03] px-3 py-2.5 text-sm leading-relaxed text-slate-200">
                          {act.bubble}
                        </p>
                      </div>

                      <div>
                        <p className="mb-1.5 text-xs font-medium text-slate-400">Completed Actions Today</p>
                        <p className="text-3xl font-bold text-white">{act.actions}</p>
                      </div>

                      <div>
                        <p className="mb-1.5 text-xs font-medium text-slate-400">Task Queue</p>
                        <ul className="space-y-1.5 text-xs text-slate-400">
                          {agent.sources.map((s) => (
                            <li key={s} className="flex items-center gap-2 rounded-lg bg-white/[0.03] px-3 py-2">
                              <span className="h-1 w-1 rounded-full" style={{ backgroundColor: agent.color }} />
                              Listening to <span className="font-mono text-slate-300">{s}</span> events
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="border-t border-white/[0.06] p-5">
                      <button
                        type="button"
                        onClick={() => onPauseToggle(agent.id)}
                        className={`flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-colors ${
                          paused[agent.id]
                            ? 'bg-emerald-500 text-emerald-950 hover:bg-emerald-400'
                            : 'bg-white/[0.08] text-slate-200 hover:bg-white/[0.14]'
                        }`}
                      >
                        {paused[agent.id] ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                        {paused[agent.id] ? 'Resume Agent' : 'Pause Agent'}
                      </button>
                    </div>
                  </>
                );
              })()}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
