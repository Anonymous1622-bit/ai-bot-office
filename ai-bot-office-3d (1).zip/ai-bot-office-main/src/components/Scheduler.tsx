import { useEffect, useMemo, useState } from 'react';
import { Bot, CalendarClock, CheckCircle2, Trash2, XCircle } from 'lucide-react';
import type { Post } from '@/lib/types';
import { db } from '@/lib/db';
import { Badge, Button, Card, EmptyState, Toggle } from './ui';

function statusBadge(status: Post['status']) {
  if (status === 'published') return <Badge tone="green">Published</Badge>;
  if (status === 'failed') return <Badge tone="red">Failed</Badge>;
  if (status === 'draft') return <Badge tone="slate">Draft</Badge>;
  return <Badge tone="amber">Scheduled</Badge>;
}

export default function Scheduler({
  autoPilot,
  onAutoPilotChange,
}: {
  autoPilot: boolean;
  onAutoPilotChange: (v: boolean) => void;
}) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [view, setView] = useState<'list' | 'calendar'>('list');
  const [error, setError] = useState('');

  const load = async () => {
    try {
      setPosts(await db.listPosts());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load queue');
    }
  };

  useEffect(() => {
    void load();
    const t = window.setInterval(() => void load(), 5000);
    return () => window.clearInterval(t);
  }, []);

  const remove = async (id: string) => {
    try {
      await db.deletePost(id);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete post');
    }
  };

  const dayGroups = useMemo(() => {
    const map = new Map<string, Post[]>();
    for (const p of posts) {
      const key = new Date(p.scheduled_at).toDateString();
      const arr = map.get(key) ?? [];
      arr.push(p);
      map.set(key, arr);
    }
    return [...map.entries()];
  }, [posts]);

  return (
    <div className="space-y-5">
      <Card className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <span className={`rounded-lg p-2.5 ${autoPilot ? 'bg-emerald-500/10 text-emerald-400' : 'bg-white/[0.06] text-slate-500'}`}>
            <Bot className="h-5 w-5" />
          </span>
          <div>
            <h3 className="text-sm font-semibold text-white">Auto-Pilot Mode</h3>
            <p className="text-xs text-slate-400">
              {autoPilot
                ? 'The bot drafts and queues a fresh post daily for each active game.'
                : 'Turn on to let the bot generate and queue posts automatically.'}
            </p>
          </div>
        </div>
        <Toggle checked={autoPilot} onChange={onAutoPilotChange} label={autoPilot ? 'On' : 'Off'} />
      </Card>

      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-white">Post Queue</h2>
        <div className="flex rounded-lg border border-white/[0.08] bg-white/[0.03] p-0.5">
          {(['list', 'calendar'] as const).map((v) => (
            <button
              key={v}
              type="button"
              onClick={() => setView(v)}
              className={`rounded-md px-3 py-1.5 text-xs font-medium capitalize transition-colors ${
                view === v ? 'bg-emerald-500/15 text-emerald-300' : 'text-slate-400 hover:text-white'
              }`}
            >
              {v}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2 text-sm text-red-300">{error}</div>
      )}

      {posts.length === 0 ? (
        <Card>
          <EmptyState
            icon={<CalendarClock className="h-10 w-10" />}
            title="Queue is empty"
            subtitle="Generate a post in the AI Studio and queue it, or switch on Auto-Pilot."
          />
        </Card>
      ) : view === 'list' ? (
        <Card>
          <ul className="divide-y divide-white/[0.05]">
            {posts.map((p) => (
              <li key={p.id} className="flex items-start justify-between gap-4 px-5 py-4">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    {statusBadge(p.status)}
                    <span className="text-xs font-medium text-slate-400">{p.game_title}</span>
                    <span className="text-xs text-slate-600">·</span>
                    <span className="text-xs capitalize text-slate-500">{p.tone} tone</span>
                  </div>
                  <p className="mt-1.5 line-clamp-2 whitespace-pre-wrap text-sm text-slate-200">{p.content}</p>
                  {p.hashtags && <p className="mt-1 text-xs text-emerald-400/70">{p.hashtags}</p>}
                  <p className="mt-1.5 text-xs text-slate-500">
                    {p.platforms.join(' · ')} —{' '}
                    {new Date(p.scheduled_at).toLocaleString([], {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                    {p.published_at && ' (sent)'}
                  </p>
                </div>
                <Button variant="ghost" className="!p-2" onClick={() => remove(p.id)} aria-label="Delete post">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </li>
            ))}
          </ul>
        </Card>
      ) : (
        <div className="space-y-4">
          {dayGroups.map(([day, dayPosts]) => (
            <Card key={day} className="p-5">
              <h4 className="text-sm font-semibold text-white">{day}</h4>
              <ul className="mt-3 space-y-3">
                {dayPosts.map((p) => {
                  const Icon = p.status === 'published' ? CheckCircle2 : p.status === 'failed' ? XCircle : CalendarClock;
                  return (
                    <li key={p.id} className="flex items-start gap-3 rounded-lg bg-white/[0.03] p-3">
                      <Icon
                        className={`mt-0.5 h-4 w-4 shrink-0 ${
                          p.status === 'published' ? 'text-emerald-400' : p.status === 'failed' ? 'text-red-400' : 'text-sky-400'
                        }`}
                      />
                      <div className="min-w-0 flex-1">
                        <p className="line-clamp-1 text-sm text-slate-200">{p.content.split('\n')[0]}</p>
                        <p className="mt-0.5 text-xs text-slate-500">
                          {new Date(p.scheduled_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ·{' '}
                          {p.game_title} · {p.platforms.join(', ')}
                        </p>
                      </div>
                      {statusBadge(p.status)}
                    </li>
                  );
                })}
              </ul>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
