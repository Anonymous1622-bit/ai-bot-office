// Gemini-backed AI caption generator. Reads the GEMINI_API_KEY (falls back to
// OPENAI_API_KEY) from function secrets, never from the client.
import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const TONE_HINTS: Record<string, string> = {
  hype: 'high-energy, exclamation-driven launch hype',
  competitive: 'ranked-season, skill-grind, competitive edge',
  casual: 'friendly, relaxed, community-warm',
  fomo: 'limited-time urgency, scarcity, act-now',
};

const PLATFORM_HINTS: Record<string, string> = {
  facebook: 'Facebook: longer, story-driven, invite comments',
  twitter: 'X/Twitter: punchy, under 280 characters',
  discord: 'Discord: community call-out, markdown-friendly',
  telegram: 'Telegram: short broadcast, channel voice',
};

interface GameInfo {
  title: string;
  genre: string;
  description: string;
  promo_link: string;
}

function buildPrompt(game: GameInfo, platform: string, tone: string): string {
  return `You are a social media copywriter for an indie game studio. Write one promotional post.

Game: ${game.title}
Genre: ${game.genre || 'unspecified'}
Description: ${game.description || 'none'}
Promo link: ${game.promo_link || 'none'}
Platform: ${PLATFORM_HINTS[platform] ?? platform}
Tone: ${TONE_HINTS[tone] ?? tone}

Return ONLY valid JSON (no markdown fences) in exactly this shape:
{"content":"the post copy with the promo link included on its own line if present","hashtags":"#tag1 #tag2 #tag3 #tag4"}`;
}

async function callGemini(apiKey: string, prompt: string): Promise<{ content: string; hashtags: string }> {
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.9, maxOutputTokens: 400 },
      }),
    }
  );
  if (!res.ok) {
    const detail = await res.text();
    throw new Error(`Gemini API error ${res.status}: ${detail.slice(0, 300)}`);
  }
  const data = await res.json();
  const text: string | undefined = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('Gemini returned no text');
  const cleaned = text.replace(/```json|```/g, '').trim();
  const parsed = JSON.parse(cleaned);
  if (typeof parsed.content !== 'string' || typeof parsed.hashtags !== 'string') {
    throw new Error('Gemini response missing content/hashtags');
  }
  return { content: parsed.content, hashtags: parsed.hashtags };
}

async function callOpenAI(apiKey: string, prompt: string): Promise<{ content: string; hashtags: string }> {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.9,
      max_tokens: 400,
      response_format: { type: 'json_object' },
    }),
  });
  if (!res.ok) {
    const detail = await res.text();
    throw new Error(`OpenAI API error ${res.status}: ${detail.slice(0, 300)}`);
  }
  const data = await res.json();
  const text: string | undefined = data?.choices?.[0]?.message?.content;
  if (!text) throw new Error('OpenAI returned no text');
  const parsed = JSON.parse(text.trim());
  if (typeof parsed.content !== 'string' || typeof parsed.hashtags !== 'string') {
    throw new Error('OpenAI response missing content/hashtags');
  }
  return { content: parsed.content, hashtags: parsed.hashtags };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { game, platform, tone } = await req.json();
    if (!game || typeof game.title !== 'string') {
      return new Response(JSON.stringify({ error: 'Missing game info' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const geminiKey = Deno.env.get('GEMINI_API_KEY');
    const openaiKey = Deno.env.get('OPENAI_API_KEY');

    if (!geminiKey && !openaiKey) {
      return new Response(JSON.stringify({ error: 'no_key_configured' }), {
        status: 503,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const prompt = buildPrompt(game, platform, tone);
    const result = geminiKey
      ? await callGemini(geminiKey, prompt)
      : await callOpenAI(openaiKey!, prompt);

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Generation failed';
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
