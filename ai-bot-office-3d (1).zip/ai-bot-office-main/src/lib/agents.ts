export type AgentId = 'aria' | 'blaze' | 'nova' | 'cipher';

export type AgentStatus = 'idle' | 'thinking' | 'typing' | 'posting' | 'paused';

export interface AgentDef {
  id: AgentId;
  name: string;
  role: string;
  color: string;
  glow: string;
  /** positions on the 900x520 office floor (isometric SVG coords) */
  x: number;
  y: number;
  sources: string[];
  idleLines: string[];
}

export const AGENTS: AgentDef[] = [
  {
    id: 'aria',
    name: 'Aria',
    role: 'Content Strategist & Copywriter',
    color: '#34d399',
    glow: 'rgba(52, 211, 153, 0.35)',
    x: 200,
    y: 150,
    sources: ['ai-studio', 'auto-pilot'],
    idleLines: ['Brainstorming fresh hooks…', 'Reading your game profiles…', 'Resting between drafts…'],
  },
  {
    id: 'blaze',
    name: 'Blaze',
    role: 'Social Media Publisher',
    color: '#38bdf8',
    glow: 'rgba(56, 189, 248, 0.35)',
    x: 620,
    y: 150,
    sources: ['auto-poster', 'scheduler'],
    idleLines: ['Watching the posting queue…', 'Verifying platform connections…', 'Awaiting next publish slot…'],
  },
  {
    id: 'nova',
    name: 'Nova',
    role: 'Community Outreach & Auto-Invite',
    color: '#f472b6',
    glow: 'rgba(244, 114, 182, 0.35)',
    x: 200,
    y: 390,
    sources: ['auto-inviter'],
    idleLines: ['Scanning for new players…', 'Listening for keyword comments…', 'Radar sweep in progress…'],
  },
  {
    id: 'cipher',
    name: 'Cipher',
    role: 'Analytics & Anti-Ban Security',
    color: '#fbbf24',
    glow: 'rgba(251, 191, 36, 0.35)',
    x: 620,
    y: 390,
    sources: ['system'],
    idleLines: ['Rate limits nominal.', 'Monitoring engagement graphs…', 'Sweeping for ban-risk patterns…'],
  },
];

export const AGENT_BY_ID = Object.fromEntries(AGENTS.map((a) => [a.id, a])) as Record<AgentId, AgentDef>;
