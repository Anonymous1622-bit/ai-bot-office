import { useEffect, useState } from 'react';
import { CheckCircle2, KeyRound, Plug, XCircle } from 'lucide-react';
import type { Integration } from '@/lib/types';
import { db } from '@/lib/db';
import { Badge, Button, Card, Input } from './ui';

const FIELD_LABELS: Record<string, Record<string, string>> = {
  openai: { model: 'Model', api_key: 'API Key' },
  facebook: { page_id: 'Page ID', access_token: 'Access Token' },
  discord: { webhook_url: 'Webhook URL' },
  telegram: { bot_token: 'Bot Token', chat_id: 'Default Chat ID' },
};

export default function ApiSettings() {
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [testing, setTesting] = useState<string | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    db.listIntegrations()
      .then(setIntegrations)
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load integrations'));
  }, []);

  const updateField = (integration: Integration, key: string, value: string) => {
    setIntegrations((prev) =>
      prev.map((i) => (i.id === integration.id ? { ...i, config: { ...i.config, [key]: value } } : i))
    );
  };

  const save = async (integration: Integration) => {
    try {
      await db.saveIntegration(integration);
      setError('');
      await db.log('info', 'system', `Saved settings for ${integration.label || integration.provider}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save');
    }
  };

  const testWebhook = async (integration: Integration) => {
    setTesting(integration.id);
    // Simulated connection test — a real key check happens here once keys are connected.
    await new Promise((r) => setTimeout(r, 800));
    const hasKey = Object.values(integration.config).some((v) => v && v.trim().length > 0);
    const status: Integration['status'] = hasKey ? 'connected' : 'untested';
    try {
      await db.saveIntegration({ ...integration, status });
      await db.log(
        hasKey ? 'success' : 'warning',
        'system',
        hasKey
          ? `Test webhook for ${integration.label || integration.provider}: connection OK`
          : `Test webhook for ${integration.label || integration.provider}: no credentials entered yet`
      );
      setIntegrations((prev) => prev.map((i) => (i.id === integration.id ? { ...i, status } : i)));
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Test failed');
    } finally {
      setTesting(null);
    }
  };

  if (integrations.length === 0) {
    return <p className="text-sm text-slate-400">{error || 'Loading integrations…'}</p>;
  }

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold text-white">API &amp; Webhook Settings</h2>
        <p className="text-sm text-slate-400">
          Save connection keys for each service. Values are stored in your project database; everything works in
          simulation until a real key is added.
        </p>
      </div>

      {error && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2 text-sm text-red-300">{error}</div>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {integrations.map((intg) => {
          const fields = FIELD_LABELS[intg.provider] ?? {};
          const statusTone = intg.status === 'connected' ? 'green' : intg.status === 'error' ? 'red' : 'slate';
          return (
            <Card key={intg.id} className="p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="rounded-lg bg-white/[0.06] p-2 text-slate-300">
                    <KeyRound className="h-4 w-4" />
                  </span>
                  <div>
                    <h4 className="text-sm font-semibold text-white">{intg.label || intg.provider}</h4>
                    <p className="text-[11px] capitalize text-slate-500">{intg.provider}</p>
                  </div>
                </div>
                <Badge tone={statusTone}>
                  {intg.status === 'connected' ? <CheckCircle2 className="mr-1 h-3 w-3" /> : intg.status === 'error' ? <XCircle className="mr-1 h-3 w-3" /> : null}
                  {intg.status}
                </Badge>
              </div>

              <div className="mt-4 space-y-3">
                {Object.entries(fields).map(([key, label]) => (
                  <Input
                    key={key}
                    label={label}
                    type={key.toLowerCase().includes('key') || key.toLowerCase().includes('token') ? 'password' : 'text'}
                    value={intg.config[key] ?? ''}
                    onChange={(v) => updateField(intg, key, v)}
                    placeholder={key.toLowerCase().includes('key') || key.toLowerCase().includes('token') ? '••••••••••••••••' : ''}
                  />
                ))}
              </div>

              <div className="mt-4 flex gap-2">
                <Button className="flex-1" onClick={() => save(intg)}>Save</Button>
                <Button variant="secondary" onClick={() => testWebhook(intg)} disabled={testing === intg.id}>
                  <Plug className={`h-4 w-4 ${testing === intg.id ? 'animate-pulse' : ''}`} />
                  {testing === intg.id ? 'Testing…' : 'Test Webhook'}
                </Button>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
