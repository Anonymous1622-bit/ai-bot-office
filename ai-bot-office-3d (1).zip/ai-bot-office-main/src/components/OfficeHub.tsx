import { useEffect, useState } from 'react';
import type { BotLog } from '@/lib/types';
import type { AgentId } from '@/lib/agents';
import { useAgentActivity } from '@/lib/useAgentActivity';
import VirtualOffice from './VirtualOffice';

export default function OfficeHub({ logs, autoPilot }: { logs: BotLog[]; autoPilot: boolean }) {
  const [now, setNow] = useState(() => new Date());
  const [paused, setPaused] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const activity = useAgentActivity(logs, autoPilot, paused);
  const hour = now.getHours();
  const isNight = hour >= 19 || hour < 7;

  const clock = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  const togglePause = (id: AgentId) => {
    setPaused((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <VirtualOffice
      activity={activity}
      clock={clock}
      isNight={isNight}
      paused={paused}
      onPauseToggle={togglePause}
    />
  );
}
