import { isSupabaseConfigured, supabase } from './supabase';
import type { BotLog, Game, Integration, InviteRule, LogLevel, Post } from './types';

async function log(level: LogLevel, source: string, message: string) {
  const { error } = await supabase
    .from('bot_logs')
    .insert({ level, source, message });
  if (error) console.error('Failed to write log:', error.message);
}

async function all<T>(table: string): Promise<T[]> {
  const { data, error } = await supabase
    .from(table)
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as T[];
}

const remoteDb = {
  async listGames() {
    return all<Game>('games');
  },
  async saveGame(game: Partial<Game> & { title: string }) {
    if (game.id) {
      const { error } = await supabase.from('games').update(game).eq('id', game.id);
      if (error) throw new Error(error.message);
      return;
    }
    const { error } = await supabase.from('games').insert(game);
    if (error) throw new Error(error.message);
  },
  async deleteGame(id: string) {
    const { error } = await supabase.from('games').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },

  async listPosts() {
    const { data, error } = await supabase
      .from('scheduled_posts')
      .select('*')
      .order('scheduled_at', { ascending: false });
    if (error) throw new Error(error.message);
    // the worker uses 'queued'; the UI calls the same state 'scheduled'
    return ((data ?? []) as Record<string, unknown>[]).map((r) => ({
      ...r,
      status: r.status === 'queued' ? 'scheduled' : r.status,
    })) as unknown as Post[];
  },
  async savePost(input: Partial<Post> & { game_id: string | null; game_title: string }) {
    const post = { ...input, status: input.status === 'scheduled' ? 'queued' : input.status };
    if (post.id) {
      const { error } = await supabase.from('scheduled_posts').update(post).eq('id', post.id);
      if (error) throw new Error(error.message);
      return;
    }
    const { error } = await supabase.from('scheduled_posts').insert(post);
    if (error) throw new Error(error.message);
  },
  async deletePost(id: string) {
    const { error } = await supabase.from('scheduled_posts').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },

  async listInviteRules() {
    return all<InviteRule>('invite_rules');
  },
  async saveInviteRule(rule: Partial<InviteRule> & { name: string }) {
    if (rule.id) {
      const { error } = await supabase.from('invite_rules').update(rule).eq('id', rule.id);
      if (error) throw new Error(error.message);
      return;
    }
    const { error } = await supabase.from('invite_rules').insert(rule);
    if (error) throw new Error(error.message);
  },
  async deleteInviteRule(id: string) {
    const { error } = await supabase.from('invite_rules').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },

  async getAutoPilot(): Promise<boolean> {
    const { data } = await supabase.from('bot_settings').select('auto_pilot_enabled').eq('id', 1).maybeSingle();
    return Boolean(data?.auto_pilot_enabled);
  },
  async setAutoPilot(enabled: boolean) {
    const { error } = await supabase
      .from('bot_settings')
      .update({ auto_pilot_enabled: enabled, updated_at: new Date().toISOString() })
      .eq('id', 1);
    if (error) throw new Error(error.message);
  },

  async listLogs(limit = 100) {
    const { data, error } = await supabase
      .from('bot_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);
    if (error) throw new Error(error.message);
    return (data ?? []) as BotLog[];
  },
  log,

  async listIntegrations() {
    const { data, error } = await supabase
      .from('integrations')
      .select('*')
      .order('created_at', { ascending: true });
    if (error) throw new Error(error.message);
    return (data ?? []) as Integration[];
  },
  async saveIntegration(integration: Integration) {
    const { error } = await supabase
      .from('integrations')
      .update({ config: integration.config, status: integration.status })
      .eq('id', integration.id);
    if (error) throw new Error(error.message);
  },
};

/* ------------------------------------------------------------------ *
 * Local mode: when Supabase env vars are missing (e.g. Netlify build
 * without them) the whole app keeps working using localStorage instead
 * of throwing errors. Data stays in this browser only.
 * ------------------------------------------------------------------ */
const LOG_EVENT = 'botoffice:log';
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);

function lread<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(`local_${key}`);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function lwrite(key: string, value: unknown) {
  try {
    localStorage.setItem(`local_${key}`, JSON.stringify(value));
  } catch {
    /* storage full/unavailable: ignore */
  }
}

type Row = { id: string; created_at: string } & Record<string, unknown>;
function upsertLocal<T extends Row>(key: string, item: Partial<T>) {
  const rows = lread<T[]>(key, []);
  if (item.id) {
    lwrite(key, rows.map((r) => (r.id === item.id ? { ...r, ...item } : r)));
  } else {
    lwrite(key, [{ ...item, id: uid(), created_at: new Date().toISOString() }, ...rows]);
  }
}
const newest = <T extends { created_at: string }>(rows: T[]) =>
  [...rows].sort((a, b) => b.created_at.localeCompare(a.created_at));

const DEFAULT_INTEGRATIONS: Integration[] = [
  { id: 'local-openai', provider: 'openai', label: 'OpenAI', config: { model: 'gpt-4o-mini', api_key: '' }, status: 'untested', created_at: '2026-01-01T00:00:00Z' },
  { id: 'local-facebook', provider: 'facebook', label: 'Facebook Page', config: { page_id: '', access_token: '' }, status: 'untested', created_at: '2026-01-01T00:00:01Z' },
  { id: 'local-discord', provider: 'discord', label: 'Discord', config: { webhook_url: '' }, status: 'untested', created_at: '2026-01-01T00:00:02Z' },
  { id: 'local-telegram', provider: 'telegram', label: 'Telegram', config: { bot_token: '', chat_id: '' }, status: 'untested', created_at: '2026-01-01T00:00:03Z' },
];

const localDb: typeof remoteDb = {
  async listGames() {
    return newest(lread<Game[]>('games', []));
  },
  async saveGame(game) {
    upsertLocal<Game & Row>('games', game as Partial<Game & Row>);
  },
  async deleteGame(id) {
    lwrite('games', lread<Game[]>('games', []).filter((g) => g.id !== id));
  },
  async listPosts() {
    return [...lread<Post[]>('posts', [])].sort((a, b) => b.scheduled_at.localeCompare(a.scheduled_at));
  },
  async savePost(input) {
    upsertLocal<Post & Row>('posts', input as Partial<Post & Row>);
  },
  async deletePost(id) {
    lwrite('posts', lread<Post[]>('posts', []).filter((p) => p.id !== id));
  },
  async listInviteRules() {
    return newest(lread<InviteRule[]>('invite_rules', []));
  },
  async saveInviteRule(rule) {
    upsertLocal<InviteRule & Row>('invite_rules', rule as Partial<InviteRule & Row>);
  },
  async deleteInviteRule(id) {
    lwrite('invite_rules', lread<InviteRule[]>('invite_rules', []).filter((r) => r.id !== id));
  },
  async getAutoPilot() {
    return lread<boolean>('auto_pilot', false);
  },
  async setAutoPilot(enabled) {
    lwrite('auto_pilot', enabled);
  },
  async listLogs(limit = 100) {
    return newest(lread<BotLog[]>('bot_logs', [])).slice(0, limit);
  },
  async log(level, source, message) {
    const row: BotLog = { id: uid(), level, source, message, created_at: new Date().toISOString() };
    lwrite('bot_logs', [row, ...lread<BotLog[]>('bot_logs', [])].slice(0, 300));
    window.dispatchEvent(new CustomEvent(LOG_EVENT, { detail: row }));
  },
  async listIntegrations() {
    return lread<Integration[]>('integrations', DEFAULT_INTEGRATIONS);
  },
  async saveIntegration(integration) {
    const rows = lread<Integration[]>('integrations', DEFAULT_INTEGRATIONS);
    lwrite('integrations', rows.map((r) => (r.id === integration.id ? integration : r)));
  },
};

export const db = isSupabaseConfigured ? remoteDb : localDb;

/** Live bot_logs feed. Uses Supabase realtime when configured, a window event in local mode. */
export function subscribeLogs(onInsert: (row: BotLog) => void): () => void {
  if (!isSupabaseConfigured) {
    const handler = (e: Event) => onInsert((e as CustomEvent<BotLog>).detail);
    window.addEventListener(LOG_EVENT, handler);
    return () => window.removeEventListener(LOG_EVENT, handler);
  }
  const channel = supabase
    .channel(`bot_logs_live_${Math.random().toString(36).slice(2)}`)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'bot_logs' }, (payload) =>
      onInsert(payload.new as BotLog)
    )
    .subscribe();
  return () => {
    void supabase.removeChannel(channel);
  };
}
