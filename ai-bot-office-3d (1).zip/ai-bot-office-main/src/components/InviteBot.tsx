import { useEffect, useState } from 'react';
import { KeyRound, Plus, ShieldAlert, Trash2 } from 'lucide-react';
import type { InviteRule, Platform } from '@/lib/types';
import { PLATFORMS } from '@/lib/types';
import { db } from '@/lib/db';
import { Badge, Button, Card, EmptyState, Input, Select, Toggle } from './ui';

const EMPTY = {
  name: '',
  platform: 'discord' as Platform,
  trigger_type: 'keyword' as 'keyword' | 'webhook',
  trigger_keywords: [] as string[],
  message_template: 'Hey {username}! Come join me in the game: {game_link}',
  target_webhook: '',
  max_per_hour: 20,
  delay_min_seconds: 30,
  delay_max_seconds: 90,
  enabled: false,
};

export default function InviteBot() {
  const [rules, setRules] = useState<InviteRule[]>([]);
  const [editing, setEditing] = useState<typeof EMPTY & { id?: string }>(EMPTY);
  const [open, setOpen] = useState(false);
  const [keywordsText, setKeywordsText] = useState('JOIN, LINK');
  const [error, setError] = useState('');

  const load = async () => {
    try {
      setRules(await db.listInviteRules());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load rules');
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const save = async () => {
    if (!editing.name.trim()) {
      setError('Rule name is required.');
      return;
    }
    const keywords = keywordsText
      .split(',')
      .map((k) => k.trim().toUpperCase())
      .filter(Boolean);
    try {
      await db.saveInviteRule({ ...editing, id: editing.id, name: editing.name.trim(), trigger_keywords: keywords });
      setOpen(false);
      setEditing(EMPTY);
      setKeywordsText('JOIN, LINK');
      setError('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save rule');
    }
  };

  const toggle = async (rule: InviteRule) => {
    try {
      await db.saveInviteRule({ ...rule, enabled: !rule.enabled });
      await db.log(
        rule.enabled ? 'warning' : 'info',
        'auto-inviter',
        `Rule "${rule.name}" ${rule.enabled ? 'disabled' : 'enabled'}`
      );
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update rule');
    }
  };

  const remove = async (id: string) => {
    try {
      await db.deleteInviteRule(id);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete rule');
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white">Auto-Invite &amp; Auto-Reply Bot</h2>
          <p className="text-sm text-slate-400">Automated outreach with rate limits to keep accounts safe.</p>
        </div>
        <Button
          onClick={() => {
            setEditing(EMPTY);
            setKeywordsText('JOIN, LINK');
            setOpen(true);
          }}
        >
          <Plus className="h-4 w-4" /> New Rule
        </Button>
      </div>

      {error && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2 text-sm text-red-300">{error}</div>
      )}

      {open && (
        <Card className="p-5">
          <h3 className="mb-4 text-sm font-semibold text-white">{editing.id ? 'Edit Rule' : 'New Invite Rule'}</h3>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Input label="Rule Name" value={editing.name} onChange={(v) => setEditing({ ...editing, name: v })} placeholder="Discord JOIN keyword" />
            <Select
              label="Platform"
              value={editing.platform}
              onChange={(v) => setEditing({ ...editing, platform: v as Platform })}
              options={PLATFORMS.map((p) => ({ value: p.id, label: p.label }))}
            />
            <Select
              label="Trigger Type"
              value={editing.trigger_type}
              onChange={(v) => setEditing({ ...editing, trigger_type: v as 'keyword' | 'webhook' })}
              options={[
                { value: 'keyword', label: 'Keyword comment (Auto-DM)' },
                { value: 'webhook', label: 'Webhook target list (Auto-send)' },
              ]}
            />
            {editing.trigger_type === 'keyword' ? (
              <Input
                label="Trigger Keywords (comma separated)"
                value={keywordsText}
                onChange={setKeywordsText}
                placeholder="JOIN, LINK"
              />
            ) : (
              <Input
                label="Target Webhook / Channel URL"
                value={editing.target_webhook}
                onChange={(v) => setEditing({ ...editing, target_webhook: v })}
                placeholder="https://discord.com/api/webhooks/…"
              />
            )}
            <label className="block md:col-span-2">
              <span className="mb-1.5 block text-xs font-medium text-slate-400">
                Message Template — use {'{username}'} and {'{game_link}'}
              </span>
              <textarea
                rows={2}
                value={editing.message_template}
                onChange={(e) => setEditing({ ...editing, message_template: e.target.value })}
                className="w-full resize-y rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-emerald-500/50"
              />
            </label>

            <div className="md:col-span-2">
              <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-slate-400">
                <ShieldAlert className="h-3.5 w-3.5 text-amber-400" /> Rate Limiting (ban protection)
              </p>
              <div className="grid grid-cols-3 gap-3">
                <Input
                  label="Max invites / hour"
                  type="number"
                  value={String(editing.max_per_hour ?? 20)}
                  onChange={(v) => setEditing({ ...editing, max_per_hour: Number(v) || 0 })}
                />
                <Input
                  label="Min delay (sec)"
                  type="number"
                  value={String(editing.delay_min_seconds ?? 30)}
                  onChange={(v) => setEditing({ ...editing, delay_min_seconds: Number(v) || 0 })}
                />
                <Input
                  label="Max delay (sec)"
                  type="number"
                  value={String(editing.delay_max_seconds ?? 90)}
                  onChange={(v) => setEditing({ ...editing, delay_max_seconds: Number(v) || 0 })}
                />
              </div>
            </div>
          </div>
          <div className="mt-4 flex items-center justify-between">
            <Toggle checked={editing.enabled ?? false} onChange={(v) => setEditing({ ...editing, enabled: v })} label="Enable immediately" />
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save}>Save Rule</Button>
            </div>
          </div>
        </Card>
      )}

      {rules.length === 0 && !open ? (
        <Card>
          <EmptyState
            icon={<KeyRound className="h-10 w-10" />}
            title="No invite rules yet"
            subtitle="Create a rule to auto-invite players who comment keywords like JOIN."
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {rules.map((r) => (
            <Card key={r.id} className="p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="truncate font-semibold text-white">{r.name}</h4>
                    <Badge tone={r.enabled ? 'green' : 'slate'}>{r.enabled ? 'Running' : 'Paused'}</Badge>
                  </div>
                  <p className="mt-0.5 text-xs text-slate-500">
                    {PLATFORMS.find((p) => p.id === r.platform)?.label} ·{' '}
                    {r.trigger_type === 'keyword' ? `keywords: ${r.trigger_keywords.join(', ') || 'none'}` : 'webhook target'}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <Button variant="ghost" className="!p-2" onClick={() => remove(r.id)} aria-label="Delete rule">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <p className="mt-3 rounded-lg bg-white/[0.03] px-3 py-2 text-xs leading-relaxed text-slate-300">
                “{r.message_template}”
              </p>
              <div className="mt-3 flex flex-wrap gap-2 text-[11px] text-slate-500">
                <Badge tone="slate">{r.max_per_hour}/hour max</Badge>
                <Badge tone="slate">{r.delay_min_seconds}–{r.delay_max_seconds}s random delay</Badge>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <Toggle checked={r.enabled} onChange={() => toggle(r)} label={r.enabled ? 'Bot active' : 'Bot paused'} />
                <Button variant="secondary" className="!py-1.5 !text-xs" onClick={() => { setEditing({ ...r }); setKeywordsText(r.trigger_keywords.join(', ')); setOpen(true); }}>
                  Edit
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
