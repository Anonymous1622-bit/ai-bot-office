/*
# AI Social Bot - Core Schema (single-tenant, no auth)

1. New Tables
- `games` - game profiles: title, genre, description, promo link, banner URL, active flag.
- `posts` - scheduled/published social posts: game ref, platforms (text[]), content, hashtags,
  tone, status (draft/scheduled/published/failed), scheduled_at, published_at.
- `invite_rules` - auto-invite trigger rules: name, platform, keyword trigger, message template,
  max invites per hour, delay range, enabled flag.
- `bot_logs` - activity feed entries: level (info/success/warning/error), source, message, created_at.
- `integrations` - one row per API connection: provider, label, config (jsonb), status (untested/connected/error).
2. Security
- Enable RLS on all tables; allow anon + authenticated CRUD because this is a single-tenant,
  no-sign-in app where the data is intentionally shared/public.
- Grant only the CRUD verbs the app uses to anon + authenticated.
3. Notes
- No user_id columns; the frontend uses the anon key for all operations.
- banner_image stores a URL (upload happens client-side or via placeholder).
*/

CREATE TABLE IF NOT EXISTS games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  genre text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  promo_link text NOT NULL DEFAULT '',
  banner_image text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid REFERENCES games(id) ON DELETE CASCADE,
  game_title text NOT NULL DEFAULT '',
  platforms text[] NOT NULL DEFAULT '{}',
  content text NOT NULL DEFAULT '',
  hashtags text NOT NULL DEFAULT '',
  tone text NOT NULL DEFAULT 'hype',
  status text NOT NULL DEFAULT 'scheduled',
  scheduled_at timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS invite_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  platform text NOT NULL DEFAULT 'discord',
  trigger_type text NOT NULL DEFAULT 'keyword',
  trigger_keywords text[] NOT NULL DEFAULT '{}',
  message_template text NOT NULL DEFAULT 'Hey {username}, join me here: {game_link}',
  target_webhook text NOT NULL DEFAULT '',
  max_per_hour integer NOT NULL DEFAULT 20,
  delay_min_seconds integer NOT NULL DEFAULT 30,
  delay_max_seconds integer NOT NULL DEFAULT 90,
  enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bot_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  level text NOT NULL DEFAULT 'info',
  source text NOT NULL DEFAULT 'system',
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS integrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL UNIQUE,
  label text NOT NULL DEFAULT '',
  config jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'untested',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE games ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE invite_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE bot_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON games TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON posts TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON invite_rules TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON bot_logs TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON integrations TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_games" ON games;
CREATE POLICY "anon_select_games" ON games FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_games" ON games;
CREATE POLICY "anon_insert_games" ON games FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_games" ON games;
CREATE POLICY "anon_update_games" ON games FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_games" ON games;
CREATE POLICY "anon_delete_games" ON games FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_posts" ON posts;
CREATE POLICY "anon_select_posts" ON posts FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_posts" ON posts;
CREATE POLICY "anon_insert_posts" ON posts FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_posts" ON posts;
CREATE POLICY "anon_update_posts" ON posts FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_posts" ON posts;
CREATE POLICY "anon_delete_posts" ON posts FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_invite_rules" ON invite_rules;
CREATE POLICY "anon_select_invite_rules" ON invite_rules FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_invite_rules" ON invite_rules;
CREATE POLICY "anon_insert_invite_rules" ON invite_rules FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_invite_rules" ON invite_rules;
CREATE POLICY "anon_update_invite_rules" ON invite_rules FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_invite_rules" ON invite_rules;
CREATE POLICY "anon_delete_invite_rules" ON invite_rules FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_bot_logs" ON bot_logs;
CREATE POLICY "anon_select_bot_logs" ON bot_logs FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_bot_logs" ON bot_logs;
CREATE POLICY "anon_insert_bot_logs" ON bot_logs FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_bot_logs" ON bot_logs;
CREATE POLICY "anon_delete_bot_logs" ON bot_logs FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_integrations" ON integrations;
CREATE POLICY "anon_select_integrations" ON integrations FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_integrations" ON integrations;
CREATE POLICY "anon_insert_integrations" ON integrations FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_integrations" ON integrations;
CREATE POLICY "anon_update_integrations" ON integrations FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_integrations" ON integrations;
CREATE POLICY "anon_delete_integrations" ON integrations FOR DELETE TO anon, authenticated USING (true);
